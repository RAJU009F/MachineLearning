import pandas_gbq
import pandas as pd
pd.set_option('display.max_colwidth', None)

c_query = """SELECT
conversation,	
content,	
language_code,	
participant,	
participant_role,	
stream_start_time,
stream_start_timestamp,
dt_skey,
utterance_start_offset,	
utterance_end_offset,	
utterance_start_timestamp,	
utterance_end_timestamp,	
SpeechWordInfo,
bq_load_dtm,
bq_load_dtm_utc

FROM  `prj-cxbi-dev-nane1-eng-edw.BI_DEV_REALTIME_LANDING.STT_MISSING_RECORDS_FROM_ONPREM_NEW`"""
df = pandas_gbq.read_gbq(c_query)
def my_fun(speechwordinfo):
	my_list = []
	for item in speechwordinfo:
		my_list.append({'WORD':item['array']['word'],'CONFIDENCE':item['array']['confidence'],'START_OFFSET':item['array']['startOffset'],'END_OFFSET':item['array']['endOffset'] })
	return my_list

df['SpeechWordInfo'] = df['SpeechWordInfo'].apply(my_fun)  
#NOT WORKING  
#pandas_gbq.to_gbq(df, 'dev_s2t_becc_redacted.STT_ONPREM_TO_GCP_FORMATTED', "itcx-bi-ccast-dev-01", if_exists='fail')

df.to_csv("gs://stt-onprem/stt_onprem_to_gcp_gd")