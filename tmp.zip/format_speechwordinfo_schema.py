import pandas_gbq
import pandas as pd
pd.set_option('display.max_colwidth', None)

c_query = """SELECT
conversation AS CONVERSATION,	
content AS CONTENT,	
language_code AS LANGUAGE_CODE,	
participant AS PARTICIPANT,	
participant_role AS PARTICIPANT_ROLE,	
stream_start_time AS STREAM_START_TIME,
stream_start_timestamp AS STREAM_START_TIMESTAMP,
dt_skey AS DT_SKEY,
utterance_start_offset AS UTTERANCE_START_OFFSET,	
utterance_end_offset AS UTTERANCE_END_OFFSET,	
utterance_start_timestamp AS UTTERANCE_START_TIMESTAMP,	
utterance_end_timestamp AS UTTERANCE_END_TIMESTAMP,	
SpeechWordInfo AS SPEECHWORDINFO,
bq_load_dtm AS BQ_LOAD_DTM,
bq_load_dtm_utc AS BQ_LOAD_DTM_UTC

FROM  `prj-cxbi-dev-nane1-eng-edw.BI_DEV_REALTIME_LANDING.STT_MISSING_RECORDS_FROM_ONPREM_NEW` WHERE DT_SKEY="2021-12-26" """
df = pandas_gbq.read_gbq(c_query)
def my_fun(speechwordinfo):
	my_list = []
	for item in speechwordinfo:
		my_list.append({'WORD':item['array']['word'],'CONFIDENCE':item['array']['confidence'],'START_OFFSET':item['array']['startOffset'],'END_OFFSET':item['array']['endOffset'] })
	return my_list

df['SPEECHWORDINFO'] = df['SPEECHWORDINFO'].apply(my_fun)  

my_schema =  [
      {
        "mode": "NULLABLE",
        "name": "CONVERSATION",
        "type": "STRING"
      },
      {
        "mode": "NULLABLE",
        "name": "CONTENT",
        "type": "STRING"
      },
      {
        "mode": "NULLABLE",
        "name": "LANGUAGE_CODE",
        "type": "STRING"
      },
      {
        "mode": "NULLABLE",
        "name": "PARTICIPANT",
        "type": "STRING"
      },
      {
        "mode": "NULLABLE",
        "name": "PARTICIPANT_ROLE",
        "type": "STRING"
      },
      {
        "mode": "NULLABLE",
        "name": "STREAM_START_TIME",
        "type": "BIGNUMERIC"
      },
      {
        "mode": "NULLABLE",
        "name": "STREAM_START_TIMESTAMP",
        "type": "TIMESTAMP"
      },
      {
        "mode": "NULLABLE",
        "name": "DT_SKEY",
        "type": "DATE"
      },
      {
        "mode": "NULLABLE",
        "name": "UTTERANCE_START_OFFSET",
        "type": "INTEGER"
      },
      {
        "mode": "NULLABLE",
        "name": "UTTERANCE_END_OFFSET",
        "type": "INTEGER"
      },
      {
        "mode": "NULLABLE",
        "name": "UTTERANCE_START_TIMESTAMP",
        "type": "TIMESTAMP"
      },
      {
        "mode": "NULLABLE",
        "name": "UTTERANCE_END_TIMESTAMP",
        "type": "TIMESTAMP"
      },
      {
        "fields": [
          {
            "mode": "NULLABLE",
            "name": "WORD",
            "type": "STRING"
          },
          {
            "mode": "NULLABLE",
            "name": "CONFIDENCE",
            "type": "FLOAT"
          },
          {
            "mode": "NULLABLE",
            "name": "END_OFFSET",
            "type": "INTEGER"
          },
          {
            "mode": "NULLABLE",
            "name": "START_OFFSET",
            "type": "INTEGER"
          }
        ],
        "mode": "REPEATED",
        "name": "SPEECHWORDINFO",
        "type": "RECORD"
      },
      {
        "mode": "NULLABLE",
        "name": "BQ_LOAD_DTM",
        "type": "TIMESTAMP"
      },
      {
        "mode": "NULLABLE",
        "name": "BQ_LOAD_DTM_UTC",
        "type": "TIMESTAMP"
      }
    ]
    
pandas_gbq.to_gbq(df, 'dev_s2t_becc_redacted.STT_ONPREM_TO_GCP_FORMATTED_NEW', "itcx-bi-ccast-dev-01", if_exists='append', table_schema=my_schema,progress_bar=True )
