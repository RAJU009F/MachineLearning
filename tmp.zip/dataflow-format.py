import apache_beam as beam
import json
from apache_beam.io.gcp.bigquery_tools import parse_table_schema_from_json
from apache_beam.options.pipeline_options import PipelineOptions
import logging

table_spec = 'prj-cxbi-dev-nane1-eng-edw:BI_DEV_REALTIME_LANDING.STT_MISSING_RECORDS_FROM_ONPREM_NEW'
table_spec2 = 'itcx-bi-ccast-dev-01:dev_s2t_becc_redacted.STT_ONPREM_TO_GCP_DATAFLOW'

my_query= """SELECT
conversation AS CONVERSATION,	
content AS CONTENT,	
language_code AS LANGUAGE_CODE,	
participant AS PARTICIPANT,	
participant_role AS PARTICIPANT_ROLE,	
stream_start_time AS STREAM_START_TIME,
stream_start_timestamp AS STREAM_START_TIMESTAMP,
dt_skey AS DT_SKEY,
utterance_start_offset AS UTTERANCE_START_OFFSET,	
utterance_end_offset AS UTTERANCE_END_OFFSET,	
utterance_start_timestamp AS UTTERANCE_START_TIMESTAMP,	
utterance_end_timestamp AS UTTERANCE_END_TIMESTAMP,	
SpeechWordInfo AS SPEECHWORDINFO,
bq_load_dtm AS BQ_LOAD_DTM,
bq_load_dtm_utc AS BQ_LOAD_DTM_UTC

FROM  `itcx-bi-ccast-dev-01.dev_s2t_becc_redacted.STT_MISSING_RECORDS_FROM_ONPREM_NEW`  """
my_schema = { 'fields': [
    {
        'mode': 'NULLABLE',
        'name': 'CONVERSATION',
        'type': 'STRING'
    },
    {
        'mode': 'NULLABLE',
        'name': 'CONTENT',
        'type': 'STRING'
    },
    {
        'mode': 'NULLABLE',
        'name': 'LANGUAGE_CODE',
        'type': 'STRING'
    },
    {
        'mode': 'NULLABLE',
        'name': 'PARTICIPANT',
        'type': 'STRING'
    },
    {
        'mode': 'NULLABLE',
        'name': 'PARTICIPANT_ROLE',
        'type': 'STRING'
    },
    {
        'mode': 'NULLABLE',
        'name': 'STREAM_START_TIME',
        'type': 'BIGNUMERIC'
    },
    {
        'mode': 'NULLABLE',
        'name': 'STREAM_START_TIMESTAMP',
        'type': 'TIMESTAMP'
    },
    {
        'mode': 'NULLABLE',
        'name': 'DT_SKEY',
        'type': 'DATE'
    },
    {
        'mode': 'NULLABLE',
        'name': 'UTTERANCE_START_OFFSET',
        'type': 'INTEGER'
    },
    {
        'mode': 'NULLABLE',
        'name': 'UTTERANCE_END_OFFSET',
        'type': 'INTEGER'
    },
    {
        'mode': 'NULLABLE',
        'name': 'UTTERANCE_START_TIMESTAMP',
        'type': 'TIMESTAMP'
    },
    {
        'mode': 'NULLABLE',
        'name': 'UTTERANCE_END_TIMESTAMP',
        'type': 'TIMESTAMP'
    },
    {
        'fields': [
        {
            'mode': 'NULLABLE',
            'name': 'WORD',
            'type': 'STRING'
        },
        {
            'mode': 'NULLABLE',
            'name': 'CONFIDENCE',
            'type': 'FLOAT'
        },
        {
            'mode': 'NULLABLE',
            'name': 'END_OFFSET',
            'type': 'INTEGER'
        },
        {
            'mode': 'NULLABLE',
            'name': 'START_OFFSET',
            'type': 'INTEGER'
        }
        ],
        'mode': 'REPEATED',
        'name': 'SPEECHWORDINFO',
        'type': 'RECORD'
    },
    {
        'mode': 'NULLABLE',
        'name': 'BQ_LOAD_DTM',
        'type': 'TIMESTAMP'
    },
    {
        'mode': 'NULLABLE',
        'name': 'BQ_LOAD_DTM_UTC',
        'type': 'TIMESTAMP'
    }
    ] }

def beam_run():
    beam_options = PipelineOptions(
        runner='DataflowRunner',
        project='itcx-bi-ccast-dev-01',
        region="northamerica-northeast1",
        job_name="onpremtogcpformat",
        temp_location='gs://dev-s2t-dataflow-bucket/ONPREM-TO-GCP-FORMAT3/temp',
        staging_location='gs://dev-s2t-dataflow-bucket/ONPREM-TO-GCP-FORMAT3/stage',
        service_account = 'dev-s2t-nordia-nlp-nlp-dataflow@itcx-bi-ccast-dev-01.iam.gserviceaccount.com ',
        use_public_ips=False,
        subnetwork="https://www.googleapis.com/compute/alpha/projects/hyc-shrd-svc-01/regions/northamerica-northeast1/subnetworks/itcx-bi-ccast-svc-subnet-dev"
    )

    class PrintFn(beam.DoFn):
        def process(self, element):
            print(element)
            logging.error(element)
            return [element] 

    pipeline = beam.Pipeline(options=beam_options)

   # my_data = pipeline | "ReadTable" >> beam.io.ReadFromBigQuery(table=table_spec)
    my_data = pipeline | "ReadTable" >> beam.io.ReadFromBigQuery(query = my_query, use_standard_sql=True)
    #my_data | "print loaded data " >> beam.ParDo(PrintFn())

    def my_fun(speechwordinfo):
        my_list = []
        for item in speechwordinfo:
            my_list.append({'WORD':item['array']['word'],'CONFIDENCE':item['array']['confidence'],'START_OFFSET':item['array']['startOffset'],'END_OFFSET':item['array']['endOffset'] })
        return my_list

    #my_data['SpeechWordInfo'] = my_data['SpeechWordInfo'].apply(my_fun)  
    class FormatFn(beam.DoFn):
        def process(self, row):
            #print(row['SPEECHWORDINFO'])
            #print("BEFORE:{}".format(row))
            #logging.error(row)
            row['SPEECHWORDINFO'] = my_fun(row['SPEECHWORDINFO'])
            #print("AFTER : {}".format(row))
            #logging.error("AFTER: {}".format(row))
            yield row
    formated_my_data = my_data | "format the SpeechWordInfo " >> beam.ParDo(FormatFn()) | "  write data to BQ " >> beam.io.WriteToBigQuery(
        table_spec2,
        schema=my_schema,
        write_disposition=beam.io.BigQueryDisposition.WRITE_TRUNCATE,
        create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

   
    #formated_my_data | "print formatted " >> beam.ParDo(PrintFn())
    # formated_my_data | "write data " >> beam.io.WriteToBigQuery(
    #     table_spec2,
    #     schema=my_schema,
    #     write_disposition=beam.io.BigQueryDisposition.WRITE_TRUNCATE,
    #     create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)
    return pipeline
pipeline = beam_run()
pipeline.run().wait_until_finish()
"""
my_column = (
 p
 | ‘ReadTable’ >> beam.io.ReadFromBigQuery(table=table_spec)
 # Each row is a dictionary where the keys are the BigQuery columns
 | beam.Map(lambda elem: elem[‘my_column’]))
 """