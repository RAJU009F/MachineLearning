from google.cloud import bigquery
from pyhive import hive
import os
import pandas as pd
import datetime
import pytz
import time
import subprocess
subprocess.run(["echo","script started running"])
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = '../prod-s2t-nordia-nlp-bq-dataflow.json'
def push_labels_from_bq_to_hadoop(dc):
    try:
        os.environ['https_proxy']="http://fastweb.int.bell.ca:8083"
        os.environ['http_proxy']="http://fastweb.int.bell.ca:8083"
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = '/app/prod-s2t-nordia-nlp-bq-dataflow.json'
        date = datetime.datetime.now(pytz.timezone('Canada/Eastern')).strftime("%Y-%m-%d")
        subprocess.run(["echo","connecting to hive"])
        def get_hive_conn():
            host = "dc5b42.bell.corp.bce.ca"

            port = 10000
            auth = 'KERBEROS'
            kerberos_service_name = "hive"
            hive_conn = hive.connect(
                    host = "dc5b42.bell.corp.bce.ca",
                    port = 10000,
                    auth = 'KERBEROS',
                    kerberos_service_name = "hive"
                )
            return hive_conn
        print("initialize hive connection")
        subprocess.run(["echo","connected to hive"])
        hive_conn = get_hive_conn()
        hive_cursor = hive_conn.cursor()

        def push_to_hive():
            filtered_results = query_from_bq()
            print("pushing data to hadoop for :{}".format(dc))
            val_str = ",".join([str(tuple(i)) for i in filtered_results])
            #print(val_str)
            hive_cursor.execute("set hive.exec.dynamic.partition.mode=nonstrict;")
            if val_str:
                subprocess.run(["echo","inserting data"])
                insert_query = f""" INSERT INTO realtime.{dc}_transcription_realtime_data_ingestion_label PARTITION (dt_skey) values {val_str} """
                if dc == 'nordia':
                    insert_query = f""" INSERT INTO realtime.transcription_realtime_data_ingestion_label PARTITION (dt_skey) values {val_str} """

                hive_cursor.execute(insert_query)
                print(" insert done for {} ".format(dc))
                subprocess.run(["echo","data inserted"])
            else:
                print("No records to push for {}, records count {} on {}".format(dc, len(val_str),date))
            pass


        def query_from_bq():
            client = bigquery.Client()
            print(date)
            bq_query = f"""
            SELECT distinct name,label,actor
            FROM  `prj-cxbi-prod-nane1-eng-edw.prod_realtime_landing.{dc}_redacted_transcription_label`
            WHERE  dt_skey = '{date}'  """
            query_job = client.query(bq_query)
            bq_results = query_job.result()  # Waits for job to complete.

            #query available 
            label_names_hive = query_from_hive()
            # filter out existing ones 
            #print(bq_results)
            filtered_results = [[row.name, row.actor, row.label, row.name.split('/')[3], row.name.split('/')[5], date ] for row in bq_results if row.name not in label_names_hive ]
            return filtered_results
            #push to have table
            #for row in results:
                #print("{} : {} ".format(row.name, row.label))
            #    if row.name in  
        def query_from_hive():
            if dc == 'nordia':
                label_query = f"""
                SELECT name
                from realtime.transcription_realtime_data_ingestion_label
                where dt_skey='{date}' 
                """
            else:
                label_query = f"""
                SELECT name
                from realtime.{dc}_transcription_realtime_data_ingestion_label
                where dt_skey='{date}'
                """

            hive_cursor.execute(label_query)
            result = hive_cursor.fetchall()
            result =  [row[0] for row in result]
            #print(result)
            return result

        #query_from_bq()
        push_to_hive()
    except Exception as e:
        print("ERROR : while processing/inserting  for {}".format( dc))
        print("error :{}".format(e))
        pass
        
if __name__ == "__main__":
    DC = ['nordia', 'becc']
    try:
        for dc in DC:
            push_labels_from_bq_to_hadoop(dc)
        subprocess.run(["echo","script has finished for {}".format(dc)])
    except Exception as e:
          print("Error while running hourly semi batch job for label transcription BQ to OnPrem {}".format(e))      