///*
// * Copyright 2021 Google LLC
// *
// * Licensed under the Apache License, Version 2.0 (the "License");
// * you may not use this file except in compliance with the License.
// * You may obtain a copy of the License at
// *
// *     http://www.apache.org/licenses/LICENSE-2.0
// *
// * Unless required by applicable law or agreed to in writing, software
// * distributed under the License is distributed on an "AS IS" BASIS,
// * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// * See the License for the specific language governing permissions and
// * limitations under the License.
// */
//package com.bell.test;
//
//
//import src.main.java.com.bell.TranscriptiontoBQ.dataflow.util.BQTableRow;
//import src.main.java.com.bell.TranscriptiontoBQ.dataflow.util.EntitySchema;
//import src.main.java.com.bell.TranscriptiontoBQ.dataflow.util.PayloadSchema;
//import src.main.java.com.bell.TranscriptiontoBQ.dataflow.util.SentimentSchema;
//import com.bell.stt.proto.TranscriptionMessage;
//import com.google.api.client.util.DateTime;
//import com.google.api.services.bigquery.model.TableRow;
//import com.google.cloud.Date;
//import com.google.protobuf.util.Durations;
//import com.google.protobuf.util.Timestamps;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.junit.Assert;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.junit.runners.JUnit4;
//
//import static com.bell.stt.proto.TranscriptionMessage.Role.ROLE_UNSPECIFIED;
//
//@RunWith(JUnit4.class)
//public class RedactedNLPtoBQTest {
//
//
//    private TranscriptionMessage.ConversationEvent createProtoRecordInput() {
//        TranscriptionMessage.ConversationEvent.Builder transcription = TranscriptionMessage.ConversationEvent.newBuilder();
//        try {
//            transcription.setConversation("Test Conversation");
//            transcription.setType(TranscriptionMessage.ConversationEvent.Type.CONVERSATION_STARTED);
//
//            TranscriptionMessage.Message.Builder msg = TranscriptionMessage.Message.newBuilder();
//            msg.setLanguageCode("en-US");
//            msg.setParticipant("participant");
//            msg.setName("project1/message1/");
//            msg.setCreateTime(Timestamps.parse("1969-12-31T23:59:59Z"));
//            msg.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
//            msg.setParticipantRole(ROLE_UNSPECIFIED);
//
//            TranscriptionMessage.NLPSentimentAnalysisResponse.Builder sr = TranscriptionMessage.NLPSentimentAnalysisResponse.newBuilder();
//            TranscriptionMessage.Document.Builder doc = TranscriptionMessage.Document.newBuilder();
//            doc.setScore(-0.3f);
//            doc.setMagnitude(0.3f);
//            sr.setLanguage("en");
//            sr.setDocument(doc.build());
//            List<TranscriptionMessage.Sentences> sentencesList = new ArrayList<TranscriptionMessage.Sentences>();
//            TranscriptionMessage.Sentences.Builder sentenceTest = TranscriptionMessage.Sentences.newBuilder();
//            TranscriptionMessage.Sentences_Sentiment.Builder sentences_sentiment_test=TranscriptionMessage.Sentences_Sentiment.newBuilder();
//            TranscriptionMessage.Text.Builder text =TranscriptionMessage.Text.newBuilder();
//            sentences_sentiment_test.setScore(-0.3f);
//            sentences_sentiment_test.setMagnitude(0.3f);
//            text.setContent("Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
//            text.setBeginoffset("-1");
//            sentenceTest.setSentencesSentiment(sentences_sentiment_test.build());
//            sentenceTest.setText(text.build());
//            sentencesList.add(sentenceTest.build());
//            sr.addAllSentences(sentencesList);
//            sr.build();
//            msg.setNLPSentimentAnalysisResponse(sr);
//            TranscriptionMessage.NLPEntityAnalysisResponse.Builder er = TranscriptionMessage.NLPEntityAnalysisResponse.newBuilder();
//            er.setLanguage("en");
//            List<TranscriptionMessage.Entities> entitiesList = new ArrayList<TranscriptionMessage.Entities>();
//            TranscriptionMessage.Entities.Builder entitiesTest = TranscriptionMessage.Entities.newBuilder();
//            TranscriptionMessage.Mentions.Builder mentionsTest = TranscriptionMessage.Mentions.newBuilder();
//            TranscriptionMessage.Mentiontext.Builder mention_text = TranscriptionMessage.Mentiontext.newBuilder();
//            TranscriptionMessage.Metadata.Builder metadata_text = TranscriptionMessage.Metadata.newBuilder();
//            mention_text.setContent("TV Box");
//            mention_text.setBeginoffset("27");
//            mention_text.build();
//            mentionsTest.setText(mention_text);
//            mentionsTest.setType("COMMON");
//            metadata_text.setValue("20");
//            entitiesTest.setName("TV Box");
//            entitiesTest.setSalience(0.7559768f);
//            entitiesTest.setTypeNlp("OTHER");
//            entitiesTest.setMentions(mentionsTest.build());
//            entitiesTest.setMetadata(metadata_text.build());
//            entitiesList.add(entitiesTest.build());
//            er.addAllEntities(entitiesList);
//            msg.setNLPEntityAnalysisResponse(er.build());
//            msg.setWordCount("19");
//            msg.setNLPAPIStartTime("12345");
//            //msg.setGCPEndTime("45678");
//            transcription.setNewMessagePayload(msg.build());
//        } catch (Exception exception) {
//            System.out.println("Unable to test" + exception);
//        }
//        return transcription.build();
//
//    }
//
//    private TableRow buildTableRowsTest(long gcpendTime)
//    {
//        TableRow row = new TableRow();
//        row.set(PayloadSchema.CONVERSATION, "Test Conversation");
//        row.set(PayloadSchema.NAME,"project1/message1/");
//        row.set(PayloadSchema.CONTENT,"Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
//        row.set(PayloadSchema.LANGUAGE_CODE, "en-US");
//        row.set(PayloadSchema.PARTICIPANT,"participant");
//        row.set(PayloadSchema.PARTICIPANT_ROLE,"ROLE_UNSPECIFIED" );
//        row.set(PayloadSchema.CREATE_TIME, ("1969-12-31 23:59:59.999")) ;
//        row.set(PayloadSchema.NLPAPISTARTTIME,"12345");
//        row.set(PayloadSchema.GCPENDTIME,gcpendTime);
//        row.set(PayloadSchema.WORDCOUNT,"19" );
//        row.set(PayloadSchema.NLP_SENTIMENT_ANALYSIS_RESPONSE,buildSentimentTest());
//        row.set(PayloadSchema.NLP_ENTITY_ANALYSIS_RESPONSE,buildEntityTest());
//
//        return  row;
//    }
//
//
//
//    private static Map<String, Object> buildSentimentTest() {
//        Map<String, Object> sentimentFields = new HashMap<>();
//
//
//        sentimentFields.put(SentimentSchema.LANGUAGE,"en");
//        Map<String, Float> documentFields = new HashMap<>();
//        documentFields.put(SentimentSchema.SCORE, -0.3f);
//        documentFields.put(SentimentSchema.MAGNITUDE, 0.3f);
//        sentimentFields.put(SentimentSchema.DOCUMENT, documentFields);
//        List<Object> sentencesListForBQ = new ArrayList<>();
//        Map<String, Object> text = new HashMap<>();
//        text.put(SentimentSchema.CONTENT,"Sam you need to reboot your TV Box by unpugging it for 20 secodns and then plugging it back");
//        text.put(SentimentSchema.BEGINOFFSET, "-1");
//        Map<String, Object> sentiment = new HashMap<>();
//        sentiment.put(SentimentSchema.SCORE, -0.3f);
//        sentiment.put(SentimentSchema.MAGNITUDE, 0.3f);
//        Map<String, Object> sentenceMap = new HashMap<>();
//        sentenceMap.put(SentimentSchema.TEXT, text);
//        sentenceMap.put(SentimentSchema.SENTENCES_SENTIMENT, sentiment);
//        sentencesListForBQ.add(sentenceMap);
//        sentimentFields.put(SentimentSchema.SENTENCES, sentencesListForBQ);
//        return sentimentFields;
//
//    }
//
//    private static Map<String, Object> buildEntityTest() {
//        Map<String, Object> entityFields = new HashMap<>();
//
//
//        entityFields.put(EntitySchema.LANGUAGE, "en");
//        List<Object> entitiesListForBQ = new ArrayList<>();
//
//
//        //Entities
//        Map<String, Object> entitiesFields = new HashMap<>();
//        entitiesFields.put(EntitySchema.NAME, "TV Box");
//        entitiesFields.put(EntitySchema.TYPE_NLP, "OTHER");
//        entitiesFields.put(EntitySchema.SALIENCE, 0.7559768f);
//
//        //Mentions
//
//        Map<String, Object> mentions = new HashMap<>();
//        mentions.put(EntitySchema.TYPE, "COMMON");
//
//        Map<String, Object> mentions_text = new HashMap<>();
//        mentions_text.put(EntitySchema.BEGINOFFSET, "27");
//        mentions_text.put(EntitySchema.CONTENT, "TV Box");
//        mentions.put(EntitySchema.TEXT, mentions_text);
//        entitiesFields.put(EntitySchema.MENTIONS, mentions);
//
//        //Metadata
//        Map<String, Object> metadata = new HashMap<>();
//        metadata.put(EntitySchema.MID, "");
//        metadata.put(EntitySchema.WIKIPEDIA_URL,"");
//        metadata.put(EntitySchema.PHONE_NUMBER,"");
//        metadata.put(EntitySchema.NATIONAL_PREFIX,"");
//        metadata.put(EntitySchema.AREA_CODE, "");
//        metadata.put(EntitySchema.EXTENSION, "");
//        metadata.put(EntitySchema.STREET_NUMBER,"");
//        metadata.put(EntitySchema.LOCALITY, "");
//        metadata.put(EntitySchema.STREET_NAME, "");
//        metadata.put(EntitySchema.POSTAL_CODE, "");
//        metadata.put(EntitySchema.COUNTRY, "");
//        metadata.put(EntitySchema.BROAD_REGION, "");
//        metadata.put(EntitySchema.NARROW_REGION, "");
//        metadata.put(EntitySchema.SUBLOCALITY, "");
//        metadata.put(EntitySchema.NUMBER, "");
//        metadata.put(EntitySchema.YEAR, "");
//        metadata.put(EntitySchema.MONTH, "");
//        metadata.put(EntitySchema.DAY, "");
//        metadata.put(EntitySchema.CURRENCY, "");
//        metadata.put(EntitySchema.VALUE, "20");
//        entitiesFields.put(EntitySchema.METADATA, metadata);
//        entitiesListForBQ.add(entitiesFields);
//        entityFields.put(EntitySchema.ENTITIES, entitiesListForBQ);
//        return entityFields;
//
//    }
//
//
//
//    @Test
//
//    public void verifyTableRow(){
//        TranscriptionMessage.ConversationEvent inputEvent = this.createProtoRecordInput();
//        long gcpendTime=System.currentTimeMillis();
//        TableRow tableExpected =this.buildTableRowsTest(gcpendTime);
//        TableRow tableActual =new BQTableRow().buildTableRows(inputEvent,gcpendTime);
//        Assert.assertEquals(tableExpected.toString(),tableActual.toString());
//    }
//}
//
//
