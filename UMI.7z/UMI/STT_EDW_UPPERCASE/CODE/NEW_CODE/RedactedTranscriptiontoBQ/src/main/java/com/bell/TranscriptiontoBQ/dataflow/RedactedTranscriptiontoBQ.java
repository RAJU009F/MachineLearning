/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.TranscriptiontoBQ.dataflow;

import com.bell.TranscriptiontoBQ.dataflow.Options.Options;
import com.bell.TranscriptiontoBQ.dataflow.transforms.BQParDo;
import com.bell.TranscriptiontoBQ.dataflow.util.SchemaUtil;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.api.services.bigquery.model.TableRow;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.bigquery.WriteResult;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.metrics.MetricNameFilter;
import org.apache.beam.sdk.metrics.MetricQueryResults;
import org.apache.beam.sdk.metrics.MetricsFilter;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;


public class RedactedTranscriptiontoBQ {

    private static final Logger LOG = LoggerFactory.getLogger(RedactedTranscriptiontoBQ.class);

    public static void main(String[] args) {
        final String METRIC_NAMESPACE = "RedactedTranscriptiontoBQ";
        try {
            Options options = PipelineOptionsFactory.fromArgs(args).withValidation().as(Options.class);
            options.setStreaming(true);

            ResourceBundle resourceBundle = getResourceBundle(options);
            options.setRegion(String.valueOf(resourceBundle.getString("region")));
            options.setGcpTempLocation(String.valueOf(resourceBundle.getString("tempLocation")));
            options.setStagingLocation(String.valueOf(resourceBundle.getString("stagingLocation")));
            options.setServiceAccount(String.valueOf(resourceBundle.getString("serviceAccount")));
            options.setRunner(DataflowRunner.class);
            options.setUsePublicIps(false);
            options.setSubnetwork(String.valueOf(resourceBundle.getString("subnetwork")));
            options.setInputSubscription(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("inputSubscription"))));
            options.setOutputTableSpec(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("outputTableSpec"))));
            options.setDeadLetterTopic(ValueProvider.StaticValueProvider.of(
                    String.valueOf(resourceBundle.getString("deadLetterTopic"))));
            options.setJobName(resourceBundle.getString("jobname"));
            PipelineResult result = run(options);


            // request the metric called "counter1" in namespace called "namespace"
            MetricQueryResults metrics =
                    result
                            .metrics()
                            .queryMetrics(
                                    MetricsFilter.builder()
                                            .addNameFilter(MetricNameFilter.named("Transcription-PubsubToBigquery", "PUBSUBTOBIGQUERY_Transcription_SUCCESS"))
                                            .addNameFilter(MetricNameFilter.named("Transcription-PubsubToBigquery", "PUBSUBTOBIGQUERY_Transcription_FAILURE"))
                                            .build());

        }catch (Exception e) {

            if (e instanceof IllegalArgumentException) {
                LOG.error("ERRTranscription306-Please Provide the correct parameter and values \n" +
                        "The Usage parameter as below \n" +
                        "\tjava -cp <target jar> --runner=dataflow --templocation=<gcs path>" +
                        "staginglocation=<gcs path> --inputSubscription=<input subscription path>" +
                        "--outputTableSpec=<Table specification> --deadLetterTopic=<Topic path> " +
                        "serviceAccount=<service account> --usePublicIps=<boolean>\n");
            }
            else
                {
                LOG.error("ERRTranscription307-Please check the google runtime error log" ,e.getMessage(),e);
            }
        }
    }


    /**
     * This Resource Bundle will take as option as parameter and read the file from the GCS bucket.
     * @param options
     * @return  PropertyResourceBundle(new InputStreamReader(new ByteArrayInputStream(blob.getContent())))
     * @throws IOException
     */
    private static ResourceBundle getResourceBundle(Options options) throws IOException {
        Storage storage = StorageOptions.newBuilder().setProjectId(options.getProject()).build().getService();
        Blob blob = storage.get(BlobId.of(options.getBucketName().get(), options.getConfigFileName().get()));
        return new PropertyResourceBundle(new InputStreamReader(new ByteArrayInputStream(blob.getContent())));
    }


    /**
     * Runs the pipeline with the supplied options.
     * 1.Read the Pubsub Message from the TranscriptionTranscription API Output
     * 2.Do the transformation
     * 3.Write the events into the BigQuery table.
     * 4.Write the failed message to the deadLetterTopic.
     * @param options
     * @return Execution of the Pipeline
     */

    public static PipelineResult run(Options options){

        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);
        final TupleTag<TranscriptionMessage.ConversationEvent> DLQ =new TupleTag<TranscriptionMessage.ConversationEvent>(){};
        final TupleTag<TableRow> SUCCESS =new TupleTag<TableRow>(){};

        try {
            LOG.info("Reading the conversation from the pubsub message");
            PCollection<TranscriptionMessage.ConversationEvent> RedactedTranscriptiontoBQ = pipeline
                    .apply(PubsubIO.readProtos(TranscriptionMessage.ConversationEvent.class).fromSubscription(options.getInputSubscription()));


            LOG.info("Building the Table and doing the transformation");
            PCollectionTuple convertedTableRow = RedactedTranscriptiontoBQ
                    .apply("Building TableRow", ParDo.of(new BQParDo(DLQ, SUCCESS)).withOutputTags(SUCCESS, TupleTagList.of(DLQ)));  // a DoFn as an anonymous inner class instance



            LOG.info("Writing the Results into BigQuery");

            WriteResult writeResult =

                    convertedTableRow.get(SUCCESS).apply("WriteSuccessfulRecords", BigQueryIO.writeTableRows()
                            .withSchema(SchemaUtil.getSchema())
                            .withMethod(BigQueryIO.Write.Method.STREAMING_INSERTS)
                            .withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND)
                            .to(options.getOutputTableSpec()));

            LOG.info("Writing the fail records into dead letter topic");


            writeResult.getFailedInserts().apply("DLQ fail inserts", ParDo.of(new DoFn<TableRow, String>() {    // a DoFn as an anonymous inner class instance
                @ProcessElement
                public void processElement(@Element TableRow error, OutputReceiver<String> out) {
                    LOG.info(error.toString());
                    out.output(error.toString());
                }
            }));


            convertedTableRow.get(DLQ).apply("DLQ BQ Events for failed message", PubsubIO.writeProtos(TranscriptionMessage.ConversationEvent.class)
                    .to(options.getDeadLetterTopic()));
        }
        catch (Exception e)
        {
            LOG.error("ERRTranscription305-Unable to process the pipeline",e.getMessage());

        }

        return pipeline.run();//.waitUntilFinish();

    }

}
