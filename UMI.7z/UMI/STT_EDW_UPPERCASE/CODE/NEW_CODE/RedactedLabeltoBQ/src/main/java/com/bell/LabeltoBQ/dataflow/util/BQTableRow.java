/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.LabeltoBQ.dataflow.util;


import com.bell.stt.proto.TranscriptionMessage;
import com.google.api.services.bigquery.model.TableRow;
import com.google.protobuf.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class BQTableRow {
    /**
     * This BQTable row build the row and add the value into the correponding fields.
     */
    static final Logger LOG = LoggerFactory.getLogger(BQTableRow.class);

    public static TableRow buildTableRows(TranscriptionMessage.ConversationEvent event,long gcpEndTime, String actor, String label,String name ) {

        TableRow row = new TableRow();
        String conversationId =event.getConversation();
        String ParticipantId =event.getNewMessagePayload().getParticipant();
        //String utteranceWordCount = event.getNewMessagePayload().getWordCount();
        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime();
        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset();
        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset();
        long labelStartTime = System.currentTimeMillis();

      final  DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd").withZone(ZoneId.of("America/New_York"));
      final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("America/New_York"));
      final DateTimeFormatter DATE_TIME_FORMATTER_UTC = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("Etc/UTC"));

        // dt_skey based on insert time   
        final long current_EST_epoch = Instant.now().toEpochMilli();
        final LocalDate current_EST_localDate = Instant.ofEpochMilli(current_EST_epoch).atZone(ZoneId.of("America/New_York")).toLocalDate();
        final String dt_skey =  DATE_FORMATTER.format(current_EST_localDate);
     
        // bq_load_dtm based on insert time   
        final LocalDateTime current_EST_localDateTime = Instant.ofEpochMilli(current_EST_epoch).atZone(ZoneId.of("America/New_York")).toLocalDateTime();
        final String bq_load_dtm =  DATE_TIME_FORMATTER.format(current_EST_localDateTime);

        // bq_load_dtm_utc based on insert time   
        final LocalDateTime current_UTC_localDateTime = Instant.ofEpochMilli(current_EST_epoch).atZone(ZoneId.of("Etc/UTC")).toLocalDateTime();
        final String bq_load_dtm_utc =  DATE_TIME_FORMATTER_UTC.format(current_UTC_localDateTime);



        try {
            long startTime = System.currentTimeMillis();
            log("The BQPardo calling for  conversation :", conversationId, ParticipantId,
                    stream_start_time, utterance_start_offset, utterance_end_offset,"Start Time ",
                    labelStartTime);
            row.set(PayloadSchema.CONVERSATION,conversationId.substring(conversationId.lastIndexOf('/')+1)) ;
            row.set(PayloadSchema.NAME, name);
            row.set(PayloadSchema.PARTICIPANT, ParticipantId.substring(ParticipantId.lastIndexOf('/')+1));
            row.set(PayloadSchema.ACTOR, actor);
            row.set(PayloadSchema.LABEL, label);
            row.set(PayloadSchema.DT_SKEY, dt_skey);
            row.set(PayloadSchema.BQ_LOAD_DTM, bq_load_dtm);
            row.set(PayloadSchema.BQ_LOAD_DTM_UTC, bq_load_dtm_utc);

            long endTime = System.currentTimeMillis();
            log("converting the Table row successfully ", conversationId, ParticipantId,
                    stream_start_time, utterance_start_offset, utterance_end_offset,
                    "Time taken ", endTime - startTime);
        }
        catch (Exception e)
        {
            logError("ERRLABELBQ302-Unable to build table rows",e,conversationId,ParticipantId
                    ,stream_start_time,utterance_start_offset,utterance_end_offset);
        }
        return row;
    }



    public static void log(String prefix,
                           String conversationId, String participantId,
                           com.google.protobuf.Timestamp stream_start_time,
                           Duration utterance_start_offset, Duration utterance_end_offset, String time , long timeTakenMs) {
        String logMessage=prefix + " ConversationId: " + conversationId + ", ParticipantId: " + participantId + ", Stream_Start_Time: " + stream_start_time +
                ", Utterance_start_offset: " + utterance_start_offset + ", utterance_end_offset: "
                + utterance_end_offset + ", "+time + timeTakenMs+"ms";

        LOG.debug(logMessage.replace("\r","").replace("\n",""));
    }

    public static void logError(String prefix,Exception e,
                                String conversationId, String participantId,
                                com.google.protobuf.Timestamp stream_start_time,
                                Duration utterance_start_offset, Duration utterance_end_offset){
        String logErrorMessage=prefix + e.getMessage() + ", ConversationId: " +conversationId
                + ", ParticipantId: " +participantId + ", Stream_Start_Time: "
                + stream_start_time + ", Utterance_start_offset: " +utterance_start_offset+  ", utterance_end_offset: "
                + utterance_end_offset;
        LOG.error(logErrorMessage.replace("\r","").replace("\n",""),e);
    }
}


