package com.bell.LabeltoBQ.dataflow.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateUtil {

    static final Logger LOG = LoggerFactory.getLogger(DateUtil.class);


    public static  boolean isNextDay(String previousDay, String currentDay , String dateFormat)
    {

       // String dateFormat = "yyyy-mm-dd";
        try {
            DateFormat requiredFormat = new SimpleDateFormat(dateFormat);
            Date prevDate = requiredFormat.parse(previousDay);
            Date currentDate = requiredFormat.parse(currentDay);
            TimeZone timeZone = TimeZone.getTimeZone("US/Eastern");
            requiredFormat.setTimeZone(timeZone);
            //System.out.println("DateUtil Compare date diff CurrentDay:"+currentDay+"  prevDay"+previousDay);
            if (prevDate.compareTo(currentDate) < 0)
                return true;
        }catch(Exception e){
            LOG.error("ERROR while comparing the dates"+e.getMessage());

        }

        return false;

    }

}