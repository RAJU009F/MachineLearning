/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.NLPtoBQ.dataflow.util;

public class EntitySchema {
    /**
     * This entity schema provide the fields use in the Entity schema.
     */

    public  static String LANGUAGE="language".toUpperCase();
    public  static String ENTITIES="entities".toUpperCase();
    public  static String NAME="name".toUpperCase();
    public  static String TYPE_NLP="type_nlp".toUpperCase();
    public  static String SALIENCE="salience".toUpperCase();
    public  static String METADATA="metadata".toUpperCase();
    public  static String MENTIONS="mentions".toUpperCase();
    public  static String TYPE="type".toUpperCase();
    public  static String TEXT="text".toUpperCase();
    public  static String CONTENT="content".toUpperCase();
    public  static String BEGINOFFSET="beginOffset".toUpperCase();
    public  static String MID ="mid".toUpperCase();
    public  static String WIKIPEDIA_URL="wikipedia_url".toUpperCase();
    public  static String PHONE_NUMBER="phone_number".toUpperCase();
    public  static String NATIONAL_PREFIX="national_prefix".toUpperCase();
    public  static String AREA_CODE="area_code".toUpperCase();
    public  static String EXTENSION="extension".toUpperCase();
    public  static String STREET_NUMBER="street_number".toUpperCase();
    public  static String LOCALITY="locality".toUpperCase();
    public  static String STREET_NAME="street_name".toUpperCase();
    public  static String POSTAL_CODE="Postal_code".toUpperCase();
    public  static String COUNTRY="country".toUpperCase();
    public  static String BROAD_REGION="broad_region".toUpperCase();
    public  static String NARROW_REGION="narrow_region".toUpperCase();
    public  static String SUBLOCALITY="sublocality".toUpperCase();
    public  static String NUMBER="number".toUpperCase();
    public  static String YEAR="year".toUpperCase();
    public  static String MONTH="month".toUpperCase();
    public  static String DAY="day".toUpperCase();
    public  static String CURRENCY="currency".toUpperCase();
    public  static String VALUE="value".toUpperCase();
}
