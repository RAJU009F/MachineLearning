/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.CallContexttoBQ.dataflow.util;

public class PayloadSchema {
    /**
     * This Payload schema provide the details of the payload fields use in message event.
     */

    public  static String EVENT_TYPE = "eventType".toUpperCase();
    public  static String ACDID="acdId".toUpperCase();
    public  static String UUI="uui".toUpperCase();
    public  static String UCID="ucid".toUpperCase();
    public  static String CALLID="callId".toUpperCase();
    public  static String AGENT_LOGINID="agentLoginId".toUpperCase();
    public  static String AGENT_EXTENSION="agentExtension".toUpperCase();
    public  static String EVENT_TIMESTAMP="eventTimeStamp".toUpperCase();
    public  static String EXTRA_CONEXTINFO="extraContextInfo".toUpperCase();
    public  static String EVENT_TIMESTAMPEPOCH="eventTimeEpoch".toUpperCase();
    public  static String DT_SKEY="dt_skey".toUpperCase();
    public  static String BQ_LOAD_DTM="bq_load_dtm".toUpperCase();
    public  static String BQ_LOAD_DTM_UTC="bq_load_dtm_utc".toUpperCase();


}
