/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.CallContexttoBQ.dataflow.util;


import com.bell.stt.proto.ContextOuterClass;
import com.google.api.services.bigquery.model.TableRow;
import com.google.protobuf.Duration;
import com.google.protobuf.util.Timestamps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;


public class BQTableRow {
    /**
     * This BQTable row build the row and add the value into the correponding fields.
     */
    static final Logger LOG = LoggerFactory.getLogger(BQTableRow.class);

    public static TableRow buildTableRows(final ContextOuterClass.Context event,final long gcpEndTime) {

          final TableRow row = new TableRow();
        final String eventType =event.getEventType().toString();
        final String acdId =event.getAcdId();
        final String uui = event.getUui();
        final String ucid =  event.getUcid();
        final String callId = event.getCallId();
        final String agentLoginId = event.getAgentLoginId();
        final String agentExtension = event.getAgentExtension();
        final com.google.protobuf.Timestamp eventTimeStamp =event.getEventTimeStamp();

        final DateTimeFormatter DATE_TIME_FORMATTER_UTC = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("Etc/UTC"));
        final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("America/New_York"));
        final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd").withZone(ZoneId.of("America/New_York"));
        final LocalDateTime event_timestamp_ltd = Instant.ofEpochMilli(Timestamps.toMillis(event.toBuilder().getEventTimeStamp()))
        .atZone(ZoneId.of("America/New_York")).toLocalDateTime();
        final String event_timestamp_string =  DATE_TIME_FORMATTER.format(event_timestamp_ltd);

        // dt_skey based on insert time   
        final long current_EST_epoch = Instant.now().toEpochMilli();
        final LocalDate current_EST_localDate = Instant.ofEpochMilli(current_EST_epoch).atZone(ZoneId.of("America/New_York")).toLocalDate();
        final String dt_skey =  DATE_FORMATTER.format(current_EST_localDate);
     
        // bq_load_dtm based on insert time   
        final LocalDateTime current_EST_localDateTime = Instant.ofEpochMilli(current_EST_epoch).atZone(ZoneId.of("America/New_York")).toLocalDateTime();
        final String bq_load_dtm =  DATE_TIME_FORMATTER.format(current_EST_localDateTime);

        // bq_load_dtm_utc based on insert time   
        final LocalDateTime current_UTC_localDateTime = Instant.ofEpochMilli(current_EST_epoch).atZone(ZoneId.of("Etc/UTC")).toLocalDateTime();
        final String bq_load_dtm_utc =  DATE_TIME_FORMATTER_UTC.format(current_UTC_localDateTime);


        try {
            final long startTime = System.currentTimeMillis();
            log("start convert callcontext  into table row :",eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension,"Time ", startTime);

          row.set(PayloadSchema.EVENT_TYPE,event.toBuilder().getEventType()) ;
          row.set(PayloadSchema.ACDID, event.toBuilder().getAcdId());
          row.set(PayloadSchema.UUI, event.toBuilder().getUui());
          row.set(PayloadSchema.UCID, event.toBuilder().getUcid());
          row.set(PayloadSchema.CALLID, event.toBuilder().getCallId());
          row.set(PayloadSchema.AGENT_LOGINID, event.toBuilder().getAgentLoginId());
          row.set(PayloadSchema.AGENT_EXTENSION, event.toBuilder().getAgentExtension());


          row.set(PayloadSchema.EVENT_TIMESTAMP, event_timestamp_string);
          row.set(PayloadSchema.EVENT_TIMESTAMPEPOCH, Timestamps.toMillis(event.toBuilder().getEventTimeStamp()));
          row.set(PayloadSchema.DT_SKEY, dt_skey);
          row.set(PayloadSchema.BQ_LOAD_DTM, bq_load_dtm);
          row.set(PayloadSchema.BQ_LOAD_DTM_UTC, bq_load_dtm_utc);


          row.set(PayloadSchema.EXTRA_CONEXTINFO, buildExtraContextInfo(event));

          final long endTime = System.currentTimeMillis();
            log("converted  callcontext  into table row :",eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension,"Time taken ", (endTime-startTime));

      }
      catch (final Exception e)
      {
          logError("ERRNLP302-Unable to build extraContextInfo rows",e,eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension);

      }
        return row;
    }

    /**
     * This BuildSentiment buid the rows of sentiment and add values corresponding to the fields.
     * @param event
     * @return sentimentFields
     */
    private  static  Map<String, Object> buildExtraContextInfo(final ContextOuterClass.Context event){
        final Map<String, Object> extraContextInfo =  new HashMap<>();

        final String eventType =event.getEventType().toString();
        final String acdId =event.getAcdId();
        final String uui = event.getUui();
        final String ucid =  event.getUcid();
        final String callId = event.getCallId();
        final String agentLoginId = event.getAgentLoginId();
        final String agentExtension = event.getAgentExtension();
        final com.google.protobuf.Timestamp eventTimeStamp =event.getEventTimeStamp();
        try {
            final long startTime = System.currentTimeMillis();

            extraContextInfo.put(ExtraContextInfo.KEY, event.getExtraContextInfo().getKey());
            extraContextInfo.put(ExtraContextInfo.VALUE, event.getExtraContextInfo().getValue());
            final long endTime = System.currentTimeMillis();
            log("Successfully converted ExtraContextInfo  into table row  callcontext :",eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension,"Time taken ", (endTime-endTime));


        } catch (final Exception e)
        {
            logError("ERRNLP302-Unable to build extraContextInfo rows",e,eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension);

        }
return  extraContextInfo;

    }

public static void log(final String prefix,
                     final String eventType, final String acdId,
                     final String uui, final com.google.protobuf.Timestamp eventTimeStamp,
                     final String ucid, final String callId, final String agentLoginId, final String agentExtension, final String time , final long timeTakenMs) {

        final String logMessage=prefix + " eventType: " + eventType + ", acdId: " + acdId +
                ", uui: " + uui + ", eventTimeStamp: " + eventTimeStamp +
                ", ucid: " + ucid + ", callId: "
                + callId + ", agentLoginId: " + agentLoginId + ", agentExtension: "
                + agentExtension +  ", "+time + timeTakenMs+"ms";

        LOG.debug(logMessage.replace("\r","").replace("\n",""));
    }


    public static void logError(final String prefix, final Exception e,
                                final String eventType, final String acdId,
                                final String uui, final com.google.protobuf.Timestamp eventTimeStamp,
                                final String ucid, final String callId, final String agentLoginId, final String agentExtension){
        final String logErrorMessage=prefix + e.getMessage() + " eventType: " + eventType + ", acdId: " + acdId +
                ", uui: " + uui + ", eventTimeStamp: " + eventTimeStamp +
                ", ucid: " + ucid + ", callId: "
                + callId + ", agentLoginId: " + agentLoginId + ", agentExtension: "
                + agentExtension ;

        LOG.error(logErrorMessage.replace("\r","").replace("\n",""),e);
    }
}


