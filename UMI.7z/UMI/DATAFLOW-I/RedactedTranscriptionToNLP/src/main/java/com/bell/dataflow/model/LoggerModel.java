/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.dataflow.model;

import com.bell.dataflow.util.NlpUtil;
import com.google.protobuf.Duration;
import com.google.protobuf.Timestamp;

/**
 * This Logger model is used to calculate the all the required fields needed to show values in the Loggers.
 */
public class LoggerModel {

    String conversationId;
    String ParticipantId;
    com.google.protobuf.Timestamp stream_start_time;
    com.google.protobuf.Duration utterance_start_offset;
    com.google.protobuf.Duration utterance_end_offset;
    int utteranceCount;


    public LoggerModel(String conversationId,
                       String participantId,
                       Timestamp stream_start_time,
                       Duration utterance_start_offset,
                       Duration utterance_end_offset,int utteranceCount) {
        this.conversationId = conversationId;
        ParticipantId = participantId;
        this.stream_start_time = stream_start_time;
        this.utterance_start_offset = utterance_start_offset;
        this.utterance_end_offset = utterance_end_offset;
        this.utteranceCount = utteranceCount;
    }

    public String getConversationId() {
        return conversationId;
    }

    public String getParticipantId() {
        return ParticipantId;
    }

    public Timestamp getStream_start_time() {
        return stream_start_time;
    }

    public Duration getUtterance_start_offset() {
        return utterance_start_offset;
    }

    public Duration getUtterance_end_offset() {
        return utterance_end_offset;
    }

    public int getUtteranceCount() {
        return utteranceCount;
    }
}
