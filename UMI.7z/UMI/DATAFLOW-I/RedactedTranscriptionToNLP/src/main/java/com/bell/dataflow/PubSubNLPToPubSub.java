/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.bell.dataflow;

import com.bell.dataflow.options.NLPOptions;
import com.bell.dataflow.transformer.NLPParDo;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.StorageOptions;
import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.metrics.MetricNameFilter;
import org.apache.beam.sdk.metrics.MetricQueryResults;
import org.apache.beam.sdk.metrics.MetricsFilter;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

public class PubSubNLPToPubSub {
    static final Logger LOG = LoggerFactory.getLogger(PubSubNLPToPubSub.class);

    /**
     *Main entry point for executing the pipeline.
     *
     * @param args
     */

    public static void main(String[] args) {
        // Parse the user options passed from the command-line
        final String METRIC_NAMESPACE = "NLPPubSubToPubSub";

        try {
            NLPOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(NLPOptions.class);

            options.setStreaming(true);

            ResourceBundle resourceBundle = getResourceBundle(options);
            options.setRegion(String.valueOf(resourceBundle.getString("region")));
            options.setGcpTempLocation(String.valueOf(resourceBundle.getString("tempLocation")));
            options.setStagingLocation(String.valueOf(resourceBundle.getString("stagingLocation")));
            options.setServiceAccount(String.valueOf(resourceBundle.getString("serviceAccount")));
            options.setRunner(DataflowRunner.class);
            options.setUsePublicIps(Boolean.valueOf(resourceBundle.getString("usePublicIps")));
            options.setSubnetwork(String.valueOf(resourceBundle.getString("subnetwork")));
            options.setInputSubscription(ValueProvider.StaticValueProvider.of(String.valueOf(resourceBundle.getString("inputSubscription"))));
            options.setOutputTopic(ValueProvider.StaticValueProvider.of(String.valueOf(resourceBundle.getString("outputTopic"))));
            options.setDeadLetterTopic(ValueProvider.StaticValueProvider.of(String.valueOf(resourceBundle.getString("deadLetterTopic"))));
            options.setMinSentimentWordCount((ValueProvider.StaticValueProvider.of(Integer.valueOf(resourceBundle.getString("minSentimentWordCount")))));
            options.setAnalyzeSentiment((ValueProvider.StaticValueProvider.of(Boolean.valueOf(resourceBundle.getString("analyzeSentiment")))));
            options.setMinEntitiesWordCount((ValueProvider.StaticValueProvider.of(Integer.valueOf(resourceBundle.getString("minEntitiesWordCount")))));
            options.setAnalyzeEntities((ValueProvider.StaticValueProvider.of(Boolean.valueOf(resourceBundle.getString("analyzeEntities")))));
            options.setLanguage(ValueProvider.StaticValueProvider.of(String.valueOf(resourceBundle.getString("language"))));
            options.setJobName(resourceBundle.getString("jobname"));

        PipelineResult result = run(options);


        MetricQueryResults metrics =
                result
                        .metrics()
                        .queryMetrics(
                                MetricsFilter.builder()
                                        .addNameFilter(MetricNameFilter.named(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_NLP_ENTITY"))
                                        .addNameFilter(MetricNameFilter.named(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_NLP_SENTIMENT"))
                                        .addNameFilter(MetricNameFilter.named(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_NLP_ENTITY_SENTIMENT"))
                                        .addNameFilter(MetricNameFilter.named(METRIC_NAMESPACE, "PUBSUBTOPUBSUB_NLP_ERROR"))
                                        .build());
    }
        catch (Exception e) {
            if (e instanceof IllegalArgumentException) {
                LOG.error("ERRNLP111-Please provide the Correct parameter and parameter values.\n" +
                        "The usage parameter follow as\n" +
                        "\tjava -cp <target jar> --runner=<dataflow> --tempLocation<GCSPath> --region=<region> " +
                        "--stagingLocation=<GCSPath> --Project=<Project name> --inputSubscription=<inputSubscription path> " +
                        "--outputTopic=<outputTopicPath> --deadLetterTopic=<deadLetterTopic> --serviceAccount=<service account> " +
                        "--usePublicIps=<boolean> --subnetwork=<subnetwork path> --minSentimentWordCount=<integer> " +
                        "--analyzeSentiment=<boolean> --minSentimentWordCount=<integer> --analyzeEntities=<boolean>\n");
            } else {
            LOG.error("ERRNLP110-Please check log for google run time exception \n" + e.getMessage(),e);
            }
        }
    }

    /**
     * This Resource Bundle will take as option as parameter and read the file from the GCS bucket.
     * @param options
     * @return  PropertyResourceBundle(new InputStreamReader(new ByteArrayInputStream(blob.getContent())))
     * @throws IOException
     */
    private static ResourceBundle getResourceBundle(NLPOptions options) throws IOException {
        Storage storage = StorageOptions.newBuilder().setProjectId(options.getProject()).build().getService();
        Blob blob = storage.get(BlobId.of(options.getBucketName().get(), options.getConfigFileName().get()));
        return new PropertyResourceBundle(new InputStreamReader(new ByteArrayInputStream(blob.getContent())));
    }


    /**
     * Runs the pipeline with the supplied options.
     * Below is the sequence of operations
     * 1. Read from PubSub and convert into transcription objects.
     * 2. Send request to NLP
     * 3. Capture the response from NLP and merge with the input.
     * 4. Write to PubSub with the  NLP output
     *
     * @param options The execution parameters to the pipeline.
     * @return The result of the pipeline execution.
     */

    public static PipelineResult run(NLPOptions options){
        // Create the pipeline
        Pipeline pipeline = Pipeline.create(options);

         final TupleTag<TranscriptionMessage.ConversationEvent> SUCCESS =
                new TupleTag<TranscriptionMessage.ConversationEvent>(){};

         final TupleTag<TranscriptionMessage.ConversationEvent> DLQ =
                new TupleTag<TranscriptionMessage.ConversationEvent>(){};

        final TupleTag<TranscriptionMessage.ConversationEvent> SUCCESS_LANGUAGE =
                new TupleTag<TranscriptionMessage.ConversationEvent>(){};

        final TupleTag<TranscriptionMessage.ConversationEvent> DLQ_LANGUAGE =
                new TupleTag<TranscriptionMessage.ConversationEvent>(){};


        try {
            LOG.info("Reading the conversation from the Subscription");
            PCollection<TranscriptionMessage.ConversationEvent> pubSubMessageNLP = pipeline
                    .apply(PubsubIO.readProtos(TranscriptionMessage.ConversationEvent.class)
                            .fromSubscription(options.getInputSubscription()));

            PCollectionTuple transcriptionWithNLPTuple = pubSubMessageNLP
                    .apply("Analysing in NLP", ParDo.of(new NLPParDo(DLQ,SUCCESS,options.getMinSentimentWordCount().get(),
                            options.getAnalyzeSentiment().get(),
                            options.getMinEntitiesWordCount().get(),
                            options.getAnalyzeEntities().get(),options.getLanguage().get())).withOutputTags(SUCCESS, TupleTagList.of(DLQ)));


            transcriptionWithNLPTuple.get(SUCCESS).apply("Write NLP Events",PubsubIO.writeProtos(TranscriptionMessage.ConversationEvent.class)
                    .to(options.getOutputTopic()));


            transcriptionWithNLPTuple.get(DLQ).apply("DLQ NLP Events",PubsubIO.writeProtos(TranscriptionMessage.ConversationEvent.class)
                    .to(options.getDeadLetterTopic()));
         } catch (Exception e) {
            LOG.error("ERRNLP109 - error processing the Pipeline",e);
        }
        return pipeline.run();

    }
}