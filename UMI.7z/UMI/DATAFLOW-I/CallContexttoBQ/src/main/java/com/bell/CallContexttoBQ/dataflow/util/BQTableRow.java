/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.CallContexttoBQ.dataflow.util;


import com.bell.stt.proto.ContextOuterClass;
import com.google.api.services.bigquery.model.TableRow;
import com.google.protobuf.Duration;
import com.google.protobuf.util.Timestamps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

public class BQTableRow {
    /**
     * This BQTable row build the row and add the value into the correponding fields.
     */
    static final Logger LOG = LoggerFactory.getLogger(BQTableRow.class);

    public static TableRow buildTableRows(final ContextOuterClass.Context event,final long gcpEndTime) {

          final TableRow row = new TableRow();
        final String eventType =event.getEventType().toString();
        final String acdId =event.getAcdId();
        final String uui = event.getUui();
        final String ucid =  event.getUcid();
        final String callId = event.getCallId();
        final String agentLoginId = event.getAgentLoginId();
        final String agentExtension = event.getAgentExtension();
        final com.google.protobuf.Timestamp eventTimeStamp =event.getEventTimeStamp();
        //long eventTimeEpochEST =  Timestamps.toMillis(event.toBuilder().getEventTimeStamp()) - 0;
//        String conversationId =event.getConversation();
//        String ParticipantId =event.getNewMessagePayload().getParticipant();
//        String utteranceWordCount = event.getNewMessagePayload().getWordCount();
//        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime();
//        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset();
//        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset();
            final String dateFormat = "YYYY-MM-dd HH:mm:ss.SSS";
            final String shortDate = "YYYY-MM-dd";
            final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
            final SimpleDateFormat shortDateFormat = new SimpleDateFormat(shortDate);

            final Calendar calendar = Calendar.getInstance();
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("EST"));
            shortDateFormat.setTimeZone(TimeZone.getTimeZone("EST"));
            //TimeZone.getTimeZone("EST")
            //event start timestamp start 
            calendar.setTimeInMillis(Timestamps.toMillis(event.toBuilder().getEventTimeStamp()));
            final String event_timestamp_string =  simpleDateFormat.format(calendar.getTime());
            final String dt_skey =  shortDateFormat.format(calendar.getTime());;
           


        try {
            final long startTime = System.currentTimeMillis();
            log("start convert callcontext  into table row :",eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension,"Time ", startTime);

          row.set(PayloadSchema.EVENT_TYPE,event.toBuilder().getEventType()) ;
          row.set(PayloadSchema.ACDID, event.toBuilder().getAcdId());
          row.set(PayloadSchema.UUI, event.toBuilder().getUui());
          row.set(PayloadSchema.UCID, event.toBuilder().getUcid());
          row.set(PayloadSchema.CALLID, event.toBuilder().getCallId());
          row.set(PayloadSchema.AGENT_LOGINID, event.toBuilder().getAgentLoginId());
          row.set(PayloadSchema.AGENT_EXTENSION, event.toBuilder().getAgentExtension());


          row.set(PayloadSchema.EVENT_TIMESTAMP, event_timestamp_string);
          row.set(PayloadSchema.EVENT_TIMESTAMPEPOCH, Timestamps.toMillis(event.toBuilder().getEventTimeStamp()));
          row.set(PayloadSchema.DT_SKEY, dt_skey);

          row.set(PayloadSchema.EXTRA_CONEXTINFO, buildExtraContextInfo(event));

          final long endTime = System.currentTimeMillis();
            log("converted  callcontext  into table row :",eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension,"Time taken ", (endTime-startTime));

      }
      catch (final Exception e)
      {
          logError("ERRNLP302-Unable to build extraContextInfo rows",e,eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension);

      }
        return row;
    }

    /**
     * This BuildSentiment buid the rows of sentiment and add values corresponding to the fields.
     * @param event
     * @return sentimentFields
     */
    private  static  Map<String, Object> buildExtraContextInfo(final ContextOuterClass.Context event){
        final Map<String, Object> extraContextInfo =  new HashMap<>();

        final String eventType =event.getEventType().toString();
        final String acdId =event.getAcdId();
        final String uui = event.getUui();
        final String ucid =  event.getUcid();
        final String callId = event.getCallId();
        final String agentLoginId = event.getAgentLoginId();
        final String agentExtension = event.getAgentExtension();
        final com.google.protobuf.Timestamp eventTimeStamp =event.getEventTimeStamp();
        try {
            final long startTime = System.currentTimeMillis();

            extraContextInfo.put(ExtraContextInfo.KEY, event.getExtraContextInfo().getKey());
            extraContextInfo.put(ExtraContextInfo.VALUE, event.getExtraContextInfo().getValue());
            final long endTime = System.currentTimeMillis();
            log("Successfully converted ExtraContextInfo  into table row  callcontext :",eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension,"Time taken ", (endTime-endTime));


        } catch (final Exception e)
        {
            logError("ERRNLP302-Unable to build extraContextInfo rows",e,eventType, acdId, uui, eventTimeStamp, ucid, callId, agentLoginId, agentExtension);

        }
return  extraContextInfo;

    }
//    private static Map<String, Object> buildSentiment(ContextOuterClass.Context event) {
//        Map<String, Object> sentimentFields = new HashMap<>();
//        String conversationId =event.getConversation();
//        String ParticipantId =event.getNewMessagePayload().getParticipant();
//        String utteranceWordCount = event.getNewMessagePayload().getWordCount();
//        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime();
//        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset();
//        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset();
//        try {
//
//            long startTime = System.currentTimeMillis();
//            log("Entering into the sentiment build table row for sentiment response",
//                    conversationId, ParticipantId, utteranceWordCount, stream_start_time,
//                    utterance_start_offset,
//                    utterance_end_offset, "start time " ,startTime);
//
//            sentimentFields.put(SentimentSchema.LANGUAGE, event.getNewMessagePayload().getNLPSentimentAnalysisResponse().getLanguage());
//
//            ContextOuterClass.NLPSentimentAnalysisResponse nlpSentimentAnalysisResponse =
//                    event.getNewMessagePayload().getNLPSentimentAnalysisResponse();
//
//            Map<String, Float> documentFields = new HashMap<>();
//            documentFields.put(SentimentSchema.SCORE, nlpSentimentAnalysisResponse.getDocument().getScore());
//            documentFields.put(SentimentSchema.MAGNITUDE, nlpSentimentAnalysisResponse.getDocument().getMagnitude());
//            sentimentFields.put(SentimentSchema.DOCUMENT, documentFields);
//
//            List<Object> sentencesListForBQ = new ArrayList<>();
//            List<TranscriptionMessage.Sentences> sentencesProto = nlpSentimentAnalysisResponse.getSentencesList();
//            for (TranscriptionMessage.Sentences sentence : sentencesProto) {
//
//                Map<String, Object> text = new HashMap<>();
//                text.put(SentimentSchema.CONTENT, sentence.getText().getContent());
//                text.put(SentimentSchema.BEGINOFFSET, sentence.getText().getBeginoffset());
//
//                Map<String, Object> sentiment = new HashMap<>();
//                sentiment.put(SentimentSchema.SCORE, sentence.getSentencesSentiment().getScore());
//                sentiment.put(SentimentSchema.MAGNITUDE, sentence.getSentencesSentiment().getMagnitude());
//
//                Map<String, Object> sentenceMap = new HashMap<>();
//                sentenceMap.put(SentimentSchema.TEXT, text);
//                sentenceMap.put(SentimentSchema.SENTENCES_SENTIMENT, sentiment);
//
//                sentencesListForBQ.add(sentenceMap);
//
//
//                sentimentFields.put(SentimentSchema.SENTENCES, sentencesListForBQ);
//                long endTime = System.currentTimeMillis();
//                log("Successfully converted sentiment Response into table row",
//                        conversationId, ParticipantId, utteranceWordCount, stream_start_time,
//                        utterance_start_offset,
//                        utterance_end_offset, "Time taken " ,(endTime-startTime));
//            }
//        }
//        catch (Exception e)
//        {
//
//            logError("ERRNLP302-Unable to build sentiment rows",e,conversationId,ParticipantId
//                    ,utteranceWordCount,stream_start_time,utterance_start_offset,utterance_end_offset);
//        }
//        return sentimentFields;
//    }
//
//    /**
//     * This Build Entity build the entity fields and add values to the corresponding fields
//     * @param event
//     * @return entityFields
//     */
//
//
//    private static Map<String, Object> buildEntity(TranscriptionMessage.ConversationEvent event) {
//        Map<String, Object> entityFields = new HashMap<>();
//        String conversationId =event.getConversation();
//        String ParticipantId =event.getNewMessagePayload().getParticipant();
//        String utteranceWordCount = event.getNewMessagePayload().getWordCount();
//        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().
//                getSpeechToTextInfo().getStreamStartTime();
//        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().
//                getSpeechToTextInfo().getUtteranceStartOffset();
//        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().
//                getSpeechToTextInfo().getUtteranceEndOffset();
//   try {
//       long startTime = System.currentTimeMillis();
//       LOG.debug("Entering the Build entities Rows");
//
//       entityFields.put(EntitySchema.LANGUAGE, event.getNewMessagePayload().getNLPEntityAnalysisResponse().getLanguage());
//
//       TranscriptionMessage.NLPEntityAnalysisResponse nlpEntityAnalysisResponse =
//               event.getNewMessagePayload().getNLPEntityAnalysisResponse();
//
//       List<Object> entitiesListForBQ = new ArrayList<>();
//       List<TranscriptionMessage.Entities> entitiesProto = nlpEntityAnalysisResponse.getEntitiesList();
//       for (TranscriptionMessage.Entities entity : entitiesProto) {
//
//           //Entities
//           Map<String, Object> entitiesFields = new HashMap<>();
//           entitiesFields.put(EntitySchema.NAME, entity.getName());
//           entitiesFields.put(EntitySchema.TYPE_NLP, entity.getTypeNlp());
//           entitiesFields.put(EntitySchema.SALIENCE, entity.getSalience());
//
//           //Mentions
//           TranscriptionMessage.Mentions mention = entity.getMentions();
//           Map<String, Object> mentions = new HashMap<>();
//           mentions.put(EntitySchema.TYPE, mention.getType());
//
//           Map<String, Object> mentions_text = new HashMap<>();
//           mentions_text.put(EntitySchema.BEGINOFFSET, mention.getText().getBeginoffset());
//           mentions_text.put(EntitySchema.CONTENT, mention.getText().getContent());
//           mentions.put(EntitySchema.TEXT, mentions_text);
//
//           entitiesFields.put(EntitySchema.MENTIONS, mentions);
//
//           //Metadata
//           TranscriptionMessage.Metadata metadataProto = entity.getMetadata();
//           Map<String, Object> metadata = new HashMap<>();
//           metadata.put(EntitySchema.MID, metadataProto.getMid());
//           metadata.put(EntitySchema.WIKIPEDIA_URL, metadataProto.getWikipediaUrl());
//           metadata.put(EntitySchema.PHONE_NUMBER, metadataProto.getPhoneNumber());
//           metadata.put(EntitySchema.NATIONAL_PREFIX, metadataProto.getNationalPrefix());
//           metadata.put(EntitySchema.AREA_CODE, metadataProto.getAreaCode());
//           metadata.put(EntitySchema.EXTENSION, metadataProto.getExtension());
//           metadata.put(EntitySchema.STREET_NUMBER, metadataProto.getStreetNumber());
//           metadata.put(EntitySchema.LOCALITY, metadataProto.getLocality());
//           metadata.put(EntitySchema.STREET_NAME, metadataProto.getStreetName());
//           metadata.put(EntitySchema.POSTAL_CODE, metadataProto.getPostalCode());
//           metadata.put(EntitySchema.COUNTRY, metadataProto.getCountry());
//           metadata.put(EntitySchema.BROAD_REGION, metadataProto.getBroadRegion());
//           metadata.put(EntitySchema.NARROW_REGION, metadataProto.getNarrowRegion());
//           metadata.put(EntitySchema.SUBLOCALITY, metadataProto.getSublocality());
//           metadata.put(EntitySchema.NUMBER, metadataProto.getNumber());
//           metadata.put(EntitySchema.YEAR, metadataProto.getYear());
//           metadata.put(EntitySchema.MONTH, metadataProto.getMonth());
//           metadata.put(EntitySchema.DAY, metadataProto.getDay());
//           metadata.put(EntitySchema.CURRENCY, metadataProto.getCurrency());
//           metadata.put(EntitySchema.VALUE, metadataProto.getValue());
//           entitiesFields.put(EntitySchema.METADATA, metadata);
//
//           entitiesListForBQ.add(entitiesFields);
//       }
//       entityFields.put(EntitySchema.ENTITIES, entitiesListForBQ);
//       long endTime = System.currentTimeMillis();
//       log("Successfully converted entity Response into table row",
//               conversationId, ParticipantId, utteranceWordCount, stream_start_time,
//               utterance_start_offset,
//               utterance_end_offset, "Time taken " ,(endTime-startTime));
//   }
//     catch (Exception e)
//        {
//            logError("ERRNLP303-Unable to build entity rows",e,conversationId,ParticipantId
//                    ,utteranceWordCount,stream_start_time,utterance_start_offset,utterance_end_offset);
//        }
//        return entityFields;
//
//    }
public static void log(final String prefix,
                     final String eventType, final String acdId,
                     final String uui, final com.google.protobuf.Timestamp eventTimeStamp,
                     final String ucid, final String callId, final String agentLoginId, final String agentExtension, final String time , final long timeTakenMs) {

        final String logMessage=prefix + " eventType: " + eventType + ", acdId: " + acdId +
                ", uui: " + uui + ", eventTimeStamp: " + eventTimeStamp +
                ", ucid: " + ucid + ", callId: "
                + callId + ", agentLoginId: " + agentLoginId + ", agentExtension: "
                + agentExtension +  ", "+time + timeTakenMs+"ms";

        LOG.debug(logMessage.replace("\r","").replace("\n",""));
    }


    public static void logError(final String prefix, final Exception e,
                                final String eventType, final String acdId,
                                final String uui, final com.google.protobuf.Timestamp eventTimeStamp,
                                final String ucid, final String callId, final String agentLoginId, final String agentExtension){
        final String logErrorMessage=prefix + e.getMessage() + " eventType: " + eventType + ", acdId: " + acdId +
                ", uui: " + uui + ", eventTimeStamp: " + eventTimeStamp +
                ", ucid: " + ucid + ", callId: "
                + callId + ", agentLoginId: " + agentLoginId + ", agentExtension: "
                + agentExtension ;

        LOG.error(logErrorMessage.replace("\r","").replace("\n",""),e);
    }
}


