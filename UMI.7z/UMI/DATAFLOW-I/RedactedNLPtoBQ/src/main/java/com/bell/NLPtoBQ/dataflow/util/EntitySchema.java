/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.NLPtoBQ.dataflow.util;

public class EntitySchema {
    /**
     * This entity schema provide the fields use in the Entity schema.
     */

    public  static String LANGUAGE="language";
    public  static String ENTITIES="entities";
    public  static String NAME="name";
    public  static String TYPE_NLP="type_nlp";
    public  static String SALIENCE="salience";
    public  static String METADATA="metadata";
    public  static String MENTIONS="mentions";
    public  static String TYPE="type";
    public  static String TEXT="text";
    public  static String CONTENT="content";
    public  static String BEGINOFFSET="beginOffset";
    public  static String MID ="mid";
    public  static String WIKIPEDIA_URL="wikipedia_url";
    public  static String PHONE_NUMBER="phone_number";
    public  static String NATIONAL_PREFIX="national_prefix";
    public  static String AREA_CODE="area_code";
    public  static String EXTENSION="extension";
    public  static String STREET_NUMBER="street_number";
    public  static String LOCALITY="locality";
    public  static String STREET_NAME="street_name";
    public  static String POSTAL_CODE="Postal_code";
    public  static String COUNTRY="country";
    public  static String BROAD_REGION="broad_region";
    public  static String NARROW_REGION="narrow_region";
    public  static String SUBLOCALITY="sublocality";
    public  static String NUMBER="number";
    public  static String YEAR="year";
    public  static String MONTH="month";
    public  static String DAY="day";
    public  static String CURRENCY="currency";
    public  static String VALUE="value";
}
