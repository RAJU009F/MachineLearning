/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.NLPtoBQ.dataflow.util;

public class PayloadSchema {
    /**
     * This Payload schema provide the details of the payload fields use in message event.
     */

    public  static String CONVERSATION ="conversation";
    public  static String NAME="name";
    public  static String CONTENT="content";
    public  static String LANGUAGE_CODE="language_code";
    public  static String PARTICIPANT="participant";
    public  static String PARTICIPANT_ROLE="participant_role";
    public  static String CREATE_TIME="create_time";
    public  static String NLPAPISTARTTIME="NLPAPIStartTime";
    public  static String GCPENDTIME="GCPEndTime";
    public  static String WORDCOUNT="wordCount";
    public  static String SPEECHTOTEXTINFO="SpeechToTextInfo";
    public  static String NLP_SENTIMENT_ANALYSIS_RESPONSE="NLP_sentiment_analysis_response";
    public  static String NLP_ENTITY_ANALYSIS_RESPONSE="NLP_entity_analysis_response";
    public  static String STREAM_START_TIME="stream_start_time";
    public  static String UTTERANCE_START_OFFSET="utterance_start_offset";
    public  static String UTTERANCE_END_OFFSET="utterance_end_offset";
    public  static String CONFIDENCE="confidence";
    public  static String SPEECHWORDINFO="SpeechWordInfo";
    public  static String START_OFFSET="start_offset";
    public  static String END_OFFSET="end_offset";
    public  static String WORD="word";
}
