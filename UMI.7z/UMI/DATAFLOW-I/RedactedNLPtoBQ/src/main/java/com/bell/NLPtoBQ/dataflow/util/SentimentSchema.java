/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.NLPtoBQ.dataflow.util;

public class SentimentSchema {
    /**
     * This sentimentSchema provide the details of the fields use in Sentiment.
     */
    public  static String LANGUAGE="language";
    public  static String DOCUMENT="document";
    public  static String SCORE="score";
    public  static String MAGNITUDE="magnitude";
    public  static String SENTENCES="sentences";
    public  static String TEXT="text";
    public  static String SENTENCES_SENTIMENT="sentences_sentiment";
    public  static String CONTENT="content";
    public  static String BEGINOFFSET="beginOffset";

}
