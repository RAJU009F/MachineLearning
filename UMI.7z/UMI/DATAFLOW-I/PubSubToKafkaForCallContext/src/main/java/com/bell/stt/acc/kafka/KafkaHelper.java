package com.bell.stt.acc.kafka;

import com.bell.stt.acc.options.AvayaCallContextOptions;
import com.bell.stt.acc.builders.KafkaSerializationBuilder;

/**
 * Helper class to build the Kafka serializable function
 */
public class KafkaHelper {

    /**
     * Method to build a Kafka serializable function
     * @param options pipeline options
     * @return Instance of the Kafka serialization builder
     */
    public static KafkaSerializationBuilder serializationBuilder(AvayaCallContextOptions options) {
        KafkaSerializationBuilder kafkaSerializationBuilder = (new KafkaSerializationBuilder()).
                setKerberosServiceNameForKafka(options.getKafkaServiceName().get()).
                setKrbFilePath(options.getKrb5ConfNameInSecretManager().get()).
                setKrbPrincipal(options.getPrincipal().get()).
                setKeytabSecretId(options.getKeytabNameInSecretManager().get()).
                setSecretProjectId(options.getProjectIdForSecret().get()).
                setTrustStorePassword(options.getTrustStorePasswordInSecretManager().get()).
                setTrustStoreSecretId(options.getTrustStoreNameInSecretManager().get()).
                setSchemaRegistryUrl(options.getschemaRegistryUrl().get()).
                setSecurityProtocol(options.getSecurityProtocol().get());
        return kafkaSerializationBuilder;
    }
}
