package com.bell.stt.acc.initializer;


import com.bell.stt.acc.options.AvayaCallContextOptions;
import com.google.auto.service.AutoService;
import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.cloud.secretmanager.v1.SecretVersionName;
import org.apache.beam.sdk.harness.JvmInitializer;
import org.apache.beam.sdk.options.PipelineOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


/**
 * Class that sets the JVM initialization parameters.
 */
@AutoService(JvmInitializer.class)
public class MyServiceInitializer implements JvmInitializer {

    private static final Logger LOG = LoggerFactory.getLogger(MyServiceInitializer.class);
    private static final String SECRETVERSION = "latest";

    /**
     * Fetches the value corresponding to the secret id and writes it into a file.
     * Prefix - file name
     * Suffix - file extension
     * @param projectId project id of the secret manager
     * @param secretId secret id of the resource being looked into secret manager
     * @param prefix file name to be created with the content from secret manager
     * @param suffix file extension
     * @return File name with the complete path
     * @throws IOException - Exception received creating the secret manager
     */
    public Path downloadSecretToLocalFile(String projectId, String secretId, String prefix, String suffix) throws IOException {
        Files.deleteIfExists(Paths.get(prefix + suffix));
        Path tmpFile = Files.createFile(Paths.get(prefix + suffix));
        try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
            SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, SECRETVERSION);
            AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);
            FileOutputStream outputStream = new FileOutputStream(tmpFile.getFileName().toFile());
            outputStream.write(response.getPayload().getData().toByteArray());
            outputStream.close();
        }
        return tmpFile;
    }

    /**
     * Fetches the value from the secret manager for the corresponding secret Id.
     * @param projectId project id of the secret manager
     * @param secretId secret id of the resource to look in secret manager
     * @return Secret value from the secret manager
     * @throws IOException - Exception received creating the secret manager
     */
    public String fetchValueFromSecretManager(String projectId, String secretId) throws IOException {
        String tempValue = "";
        try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
            SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, SECRETVERSION);
            AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);
            tempValue = response.getPayload().getData().toStringUtf8();
        }
        return tempValue;
    }

    /**
     * Method that sets the JVM initialization parameters.
     * @param options pipeline options
     */
    @Override
    public void beforeProcessing(PipelineOptions options) {
        LOG.info("Initializing worker Java System properties.");

        AvayaCallContextOptions o = options.as(AvayaCallContextOptions.class);
        if (o.getKrb5ConfNameInSecretManager() != null) {
            Path krb5Conf, truststore, keytab;
            try {
                krb5Conf = downloadSecretToLocalFile(o.getProjectIdForSecret().toString(), o.getKrb5ConfNameInSecretManager().toString() ,"krb5",".conf");
                truststore = downloadSecretToLocalFile(o.getProjectIdForSecret().toString(), o.getTrustStoreNameInSecretManager().toString(), "truststore", ".jks");
                keytab = downloadSecretToLocalFile(o.getProjectIdForSecret().toString(), o.getKeytabNameInSecretManager().toString() ,"kafka",".keytab");
                LOG.info("InitializerLog - krb5Conf filepath:" + krb5Conf.toString());
                LOG.info("InitializerLog - truststore filepath:" + truststore.toString());
                LOG.info("InitializerLog - keytab filepath:" + keytab.toString());
                System.setProperty("java.security.krb5.conf", krb5Conf.toString());
                //System.setProperty("sun.security.krb5.debug", "true");

            } catch (IOException ex) {
                LOG.error("S2T-ERR303 - Unable to download " + o.getKrb5ConfNameInSecretManager(), ex);
            }
        } else {
            LOG.info("Kerberos system properties are not configured, if Kerberos is desired,"
                    + "set both the realm and KDC options on the pipeline.");
        }
    }
}
