package com.bell.stt.acc.serialization;

import com.bell.stt.avro.Context;
import com.google.api.client.util.Preconditions;
import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.cloud.secretmanager.v1.SecretVersionName;
import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

/**
 * The class implements a serializable function for the Kafka producer config.
 */

public class KafkaSerializationFunction implements SerializableFunction<Map<String, Object>, Producer<String, Context>> {

    private static final Logger LOG = LoggerFactory.getLogger(KafkaSerializationFunction.class);
    private String keytabSecretId;
    private String trustStoreSecretId;
    private String trustStorePassword;
    private String kerbPrincipal;
    private String secretProjectId;
    private String kerberosServiceNameForKafka;
    private String schemaRegistryUrl;
    private String securityProtocol;

    private static final String SECRETVERSION = "latest";

    /**
     * Constructor
     * @param keytabSecretId secret Id for the keytab
     * @param trustStoreSecretId secret Id for the trust store
     * @param trustStorePassword trust store password
     * @param kerbPrincipal kerberos prinicipal
     * @param secretProjectId project Id of the secret manager
     * @param kerberosServiceNameForKafka Kafka service name
     * @param schemaRegistryUrl  confluent kafka schema registry
     * @param securityProtocol  SASL_SSL or SSL
     */
    public KafkaSerializationFunction(String keytabSecretId, String trustStoreSecretId,
                                      String trustStorePassword, String kerbPrincipal,
                                      String secretProjectId, String kerberosServiceNameForKafka, String schemaRegistryUrl,
                                      String securityProtocol) {
        this.keytabSecretId = keytabSecretId;
        this.trustStoreSecretId = trustStoreSecretId;
        this.trustStorePassword = trustStorePassword;
        this.kerbPrincipal = kerbPrincipal;
        this.secretProjectId = secretProjectId;
        this.kerberosServiceNameForKafka = kerberosServiceNameForKafka;
        this.schemaRegistryUrl = schemaRegistryUrl;
        this.securityProtocol = securityProtocol;

    }

    /**
     * Method to build the configuration parameter for Kafka producer
     * @param inputParams params for initializing the kafka producer
     * @return Kafka producer built with the configuration parameters
     */
    public Producer<String, Context> apply(Map<String, Object> inputParams) {

        inputParams.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl);
        inputParams.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, securityProtocol);
        inputParams.put(ProducerConfig.CLIENT_ID_CONFIG, "com.bell.stt.context.gcp-producer");
        inputParams.put(ProducerConfig.RETRIES_CONFIG, "50");
        inputParams.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG, "200");
        inputParams.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, "20");
        inputParams.put(ProducerConfig.LINGER_MS_CONFIG, "10");
        inputParams.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "lz4");

        if (keytabSecretId != null) {
            try {
                Path temp = downloadSecretToLocalFile(secretProjectId, keytabSecretId, "kafka", ".keytab");
                Preconditions.checkNotNull(temp);
                Preconditions.checkNotNull(kerbPrincipal);
                Preconditions.checkNotNull(kerberosServiceNameForKafka);
                String jaasConfig = String
                        .format("com.sun.security.auth.module.Krb5LoginModule required useKeyTab=true storeKey=true keyTab=\"%s\" principal=\"%s\";",
                                "/kafka.keytab", kerbPrincipal);
                inputParams.put(SaslConfigs.SASL_JAAS_CONFIG, jaasConfig);
                inputParams.put(SaslConfigs.SASL_MECHANISM, SaslConfigs.GSSAPI_MECHANISM);
                inputParams.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, kerberosServiceNameForKafka);
                inputParams.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, kerberosServiceNameForKafka);
                inputParams.put("ssl.endpoint.identification.algorithm", "");

            } catch (Exception e) {
                LOG.error("S2T-ERR304 - Error in retrieving key tab from secrets ", e);
            }
        }

        if (trustStoreSecretId != null) {
            try {
                Path temp = downloadSecretToLocalFile(secretProjectId, trustStoreSecretId, "truststore", ".jks");
                String trustPassword = fetchValueFromSecretManager(secretProjectId, trustStorePassword);
                inputParams.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, temp.toString());
                inputParams.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, trustPassword);
            } catch (Exception e) {
                LOG.error("S2T-ERR305 - Error in retrieving trust store details from secrets ", e);
            }
        }
        return new KafkaProducer<String, Context>(inputParams);
    }

    /**
     * Fetches the value corresponding to the secret id and writes it into a file.
     * Prefix - file name
     * Suffix - file extension
     * @param projectId  - Project id of the secret manager
     * @param secretId  - Id of the resource to be accessed
     * @param prefix - File name
     * @param suffix - File extension
     * @return File name with the complete path
     * @throws IOException Secret manager access failed.
     */
    private Path downloadSecretToLocalFile(String projectId, String secretId, String prefix, String suffix) throws IOException {
        Path tmpFile = Paths.get(prefix + suffix);
        if(Files.exists(tmpFile)){
            try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
                SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, SECRETVERSION);
                AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);
                FileOutputStream outputStream = new FileOutputStream(tmpFile.getFileName().toFile());
                outputStream.write(response.getPayload().getData().toByteArray());
                outputStream.close();
            }
        }
        return tmpFile;
    }

    /**
     * Fetches the value from the secret manager for the corresponding secret Id.
     * @param projectId  - Project id of the secret manager
     * @param secretId - Id of the resource to be accessed.
     * @return Secret value - The value of the resource in the secret manager
     * @throws IOException- Secret manager access failed.
     */
    private String fetchValueFromSecretManager(String projectId, String secretId) throws IOException {
        String tempValue = "";
        try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
            SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, SECRETVERSION);
            AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);
            tempValue = response.getPayload().getData().toStringUtf8();
        }
        return tempValue;
    }
}