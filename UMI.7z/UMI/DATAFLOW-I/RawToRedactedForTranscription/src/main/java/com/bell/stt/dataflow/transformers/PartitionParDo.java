package com.bell.stt.dataflow.transformers;

import com.bell.stt.proto.TranscriptionMessage.*;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Random;

public class PartitionParDo extends DoFn<ConversationEvent, KV<String, ConversationEvent>> {

    static final Logger LOG = LoggerFactory.getLogger(PartitionParDo.class);

    private final Integer batchNum;

    public PartitionParDo(Integer batchNum) {
        this.batchNum = batchNum;
    }

    @ProcessElement
    public void processElement(ProcessContext c) {
        try {
            KV<String, ConversationEvent> kv = KV.of(String.valueOf((new Random()).nextInt(batchNum)), c.element());
            c.output(kv);
        } catch (Exception e) {
            LOG.error("S2T-ERR103 - Unable to partition input by random key", e);
        }
    }

}
