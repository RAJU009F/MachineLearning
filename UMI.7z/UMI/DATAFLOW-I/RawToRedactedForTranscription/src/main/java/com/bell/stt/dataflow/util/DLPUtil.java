package com.bell.stt.dataflow.util;

public class DLPUtil {
    //Roughly .45MB
    private static final Integer BYTES_THRESHOLD = 235930;

    public static int calculateBatches(Integer payloadBytes) {
        int numBatches = payloadBytes / BYTES_THRESHOLD;
        int reminder = payloadBytes % BYTES_THRESHOLD;
        return reminder == 0 ? numBatches - 1 : numBatches;
    }

    public static int calculateSizeOfDLPList(Integer sizeOfList, int numSubList) {
        return numSubList == 0 ? 1 : sizeOfList / numSubList;
    }
}
