package com.bell.stt.dataflow.transformers;

import com.bell.stt.dataflow.util.DLPUtil;
import com.bell.stt.dlp.DLPService;
import com.bell.stt.proto.TranscriptionMessage.*;
import com.google.cloud.dlp.v2.DlpServiceClient;
import com.google.privacy.dlp.v2.*;
import com.google.privacy.dlp.v2.DeidentifyContentRequest.Builder;
import org.apache.beam.sdk.metrics.Distribution;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * The class is responsible for
 * a. Extract the content to redact
 * b. Build the ContentItem.
 * c. Post and retrieve the redacted data from DLP.
 * d. Merge the redacted data with the request.
 */
public class DLPParDo extends DoFn<KV<String, List<ConversationEvent>>, KV<String, ConversationEvent>> {

    static final Logger LOG = LoggerFactory.getLogger(DLPParDo.class);

    private ValueProvider<String> dlpProjectId;
    private transient DlpServiceClient dlpServiceClient;
    private ValueProvider<String> deIdentifyTemplateName;
    private ValueProvider<String> inspectTemplateName;
    private ValueProvider<Integer> batchSize;
    private boolean inspectTemplateExist;
    private transient Builder requestBuilder;
    private final Distribution numberOfRowsTokenized =
            Metrics.distribution(DLPParDo.class, "PUBSUBTOPUBSUB_STT_NUMBER_OF_ROWS_TOKENIZED_DISTRO");
    private final Distribution numberOfBytesTokenized =
            Metrics.distribution(DLPParDo.class, "PUBSUBTOPUBSUB_STT_NUMBER_OF_BYTES_TOKENIZED_DISTRO");

    /**
     * The constructor for the ParDo
     *
     * @param dlpProjectId
     * @param deIdentifyTemplateName
     * @param inspectTemplateName
     */
    public DLPParDo(
            ValueProvider<String> dlpProjectId,
            ValueProvider<String> deIdentifyTemplateName,
            ValueProvider<String> inspectTemplateName,
            ValueProvider<Integer> batchSize) {
        this.dlpProjectId = dlpProjectId;
        this.dlpServiceClient = null;
        this.deIdentifyTemplateName = deIdentifyTemplateName;
        this.inspectTemplateName = inspectTemplateName;
        this.inspectTemplateExist = false;
        this.batchSize = batchSize;
    }

    /**
     * Template method to validate the presence and then initialize the variables. In this case
     * 1. Insspection template
     * 2. De-identification template
     */
    @Setup
    public void setup() {
        if (this.inspectTemplateName.isAccessible() && this.inspectTemplateName.get() != null) {
            this.inspectTemplateExist = true;
        }
        if (this.deIdentifyTemplateName.isAccessible() && this.deIdentifyTemplateName.get() != null) {
            this.requestBuilder =
                    DeidentifyContentRequest.newBuilder()
                            .setParent(LocationName.of(this.dlpProjectId.get(), "northamerica-northeast1").toString())
                            .setDeidentifyTemplateName(this.deIdentifyTemplateName.get());
            if (this.inspectTemplateExist) {
                this.requestBuilder.setInspectTemplateName(this.inspectTemplateName.get());
            }
        }
    }

    /**
     * Template method to open any resources
     *
     * @throws IOException
     */
    @StartBundle
    public void startBundle() throws IOException {
        try {
            this.dlpServiceClient = DlpServiceClient.create();
        } catch (IOException e) {
            LOG.error("ERR101 - Unable to start DLP Client ", e);
        }
    }

    /**
     * Template method to close any resources
     */
    @FinishBundle
    public void finishBundle() {
        if (this.dlpServiceClient != null) {
            this.dlpServiceClient.close();
        }
    }

    /**
     * Method does the following
     * a. Splits the batches based on the batch size
     * b. Constructs the payload for DLP.
     * c. Triggers request to DLP.
     * d. Merges the redacted response with the batch transcriptions in the input
     * e. Writes to output
     *
     * @param c
     */

    @ProcessElement
    public void processElement(ProcessContext c) {
        try {

            List<ConversationEvent> nonEncryptedData = c.element().getValue();
            ContentItem tableItem = DLPService.buildDLPPayload(nonEncryptedData);
//            int numBatches = DLPUtil.calculateBatches(tableItem.toString().getBytes().length);
//            int numSubLists = DLPUtil.calculateSizeOfDLPList(nonEncryptedData.size(), numBatches);
//            final AtomicInteger counter = new AtomicInteger(0);
//            List<List<ConversationEvent>> batches = new ArrayList(nonEncryptedData.stream()
//                    .collect(Collectors.groupingBy(s -> counter.getAndIncrement() / numSubLists))
//                    .values());
//            LOG.info("Total batch size:" + batches.size());
//            for (List<ConversationEvent> smallerBatch : batches) {
//                LOG.info("Each batch size:" + smallerBatch.size());
//                tableItem = DLPService.buildDLPPayload(smallerBatch);
                this.requestBuilder.setItem(tableItem);
                DeidentifyContentResponse response =
                        dlpServiceClient.deidentifyContent(this.requestBuilder.build());
                Table tokenizedData = response.getItem().getTable();
                numberOfRowsTokenized.update(tokenizedData.getRowsList().size());
                numberOfBytesTokenized.update(tokenizedData.toByteArray().length);
                List<ConversationEvent> encryptedData = DLPService.buildDLPRedactedPayload(nonEncryptedData, response);
                for (ConversationEvent outRecor : encryptedData) {
                    c.output(KV.of(UUID.randomUUID().toString(), outRecor));
                }
            }
//        }
        catch (Exception e){
            LOG.error("S2T-ERR102 - Unable to redact message: "+ e.getMessage());
        }


    }
}
