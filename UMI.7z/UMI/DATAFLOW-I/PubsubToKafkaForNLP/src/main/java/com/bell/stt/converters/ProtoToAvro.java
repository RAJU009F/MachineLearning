/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.stt.converters;


import com.bell.stt.avro.*;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.protobuf.Duration;
import com.google.protobuf.util.Durations;
import com.google.protobuf.util.Timestamps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.ArrayList;

/**
 * Class converts the Context in proto format to Context in Avro format
 */
public class ProtoToAvro {

    /**
     * Method converts the proto to Avro payload
     *
     * @param payload incoming context payload in proto format
     * @return Context data in Avro format
     * @throws Exception received when converting proto to avro
     */
    private static final Logger LOG = LoggerFactory.getLogger(ProtoToAvro.class);

    public static NLPSentimentAndEntityAnalysisTranscriptionOutput convertToAvroManually(TranscriptionMessage.ConversationEvent payload) { //Static
        NLPSentimentAndEntityAnalysisTranscriptionOutput.Builder nlpSentimentAndEntityAnalysisTranscriptionOutput =
                NLPSentimentAndEntityAnalysisTranscriptionOutput.newBuilder();
        String conversationId =payload.getConversation();
        String ParticipantId =payload.getNewMessagePayload().getParticipant();
        String utteranceWordCount=payload.getNewMessagePayload().getWordCount();
        com.google.protobuf.Timestamp stream_start_time =payload.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime();
        com.google.protobuf.Duration utterance_start_offset=payload.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset();
        com.google.protobuf.Duration utterance_end_offset=payload.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset();
        long gcpEndTime = System.currentTimeMillis();
        Transcription.Builder avroRecord = Transcription.newBuilder();

        avroRecord.setConversation(payload.getConversation());
        avroRecord.setType(payload.getType().name());
        avroRecord.setGcpEndTime(gcpEndTime);

        try {
            long startTime = System.currentTimeMillis();
            log("Entering Kafka for processing and publish message into Kafka", conversationId,
                    ParticipantId, utteranceWordCount, stream_start_time, utterance_start_offset,
                    utterance_end_offset,"Start Time ", startTime);
            TranscriptionMessage.Message protoMsg = payload.getNewMessagePayload();
            NewMessagePayload.Builder msg = NewMessagePayload.newBuilder();//Avro
            long NLPApi_start_time = Long.valueOf(protoMsg.getNLPAPIStartTime());
            if (protoMsg != null) {
                msg.setContent(protoMsg.getContent());
                msg.setName(protoMsg.getName());
                msg.setLanguageCode(protoMsg.getLanguageCode());
                msg.setParticipant(protoMsg.getParticipant());
                msg.setParticipantRole(protoMsg.getParticipantRole().name());
                msg.setCreateTime(protoMsg.getCreateTime().getSeconds());
                msg.setMessageAnnotation(null);
                TranscriptionMessage.Message.SpeechToTextInfo s2tInfo = protoMsg.getSpeechToTextInfo();
                if (s2tInfo != null) {
                    msg.setStreamStartTime(Timestamps.toMillis(s2tInfo.getStreamStartTime()));
                    msg.setUtteranceStartOffset(Durations.toMillis(s2tInfo.getUtteranceStartOffset()));
                    msg.setUtteranceEndOffset(Durations.toMillis(s2tInfo.getUtteranceEndOffset()));
                }
                List<Words> avroWordsList = new ArrayList<Words>();
                for (TranscriptionMessage.Message.SpeechWordInfo words : s2tInfo.getSpeechWordInfoList()) {
                    Words avroWord = new Words();
                    avroWord.setWord(words.getWord());
                    avroWord.setConfidence(words.getConfidence());
                    avroWord.setStartOffset(Durations.toMillis(words.getStartOffset()));
                    avroWord.setEndOffset(Durations.toMillis(words.getEndOffset()));
                    avroWordsList.add(avroWord);
                }
                msg.setWords(avroWordsList);
            }


            nlpSentimentAndEntityAnalysisTranscriptionOutput.setNLPconversation(buildNLPconversation(payload));
            nlpSentimentAndEntityAnalysisTranscriptionOutput.setS2TNLPAPIAnalysisResponse(buildS2TNLPAPIAnalysisResponse(payload));
            nlpSentimentAndEntityAnalysisTranscriptionOutput.setTranscription(avroRecord.build());
            nlpSentimentAndEntityAnalysisTranscriptionOutput.setGCPEndTime(System.currentTimeMillis());
            nlpSentimentAndEntityAnalysisTranscriptionOutput.setNLPAPIStartTime(Long.valueOf(protoMsg.getNLPAPIStartTime()));
            nlpSentimentAndEntityAnalysisTranscriptionOutput.setWordCount(Long.valueOf(protoMsg.getWordCount()));
            avroRecord.setNewMessagePayload(msg.build());
            long endTime = System.currentTimeMillis();
            log("Successfully converted from proto to avro", conversationId,
                    ParticipantId, utteranceWordCount, stream_start_time, utterance_start_offset,
                    utterance_end_offset,"Start Time ", startTime);
            log("End to End before writing into kafka", conversationId,
                    ParticipantId, utteranceWordCount, stream_start_time, utterance_start_offset,
                    utterance_end_offset,"Time Taken ", (gcpEndTime -NLPApi_start_time));

        } catch (Exception e) {
            LOG.error("ERRNLP306 - Unable to convert transcription proto to avro"+" Conversation Id: " + conversationId
                    +", Participant: " + ParticipantId +", word_count: " + utteranceWordCount
                    + ", Stream_Start_Time: "+ stream_start_time + ",Utterance_start_offset: "
                    +utterance_start_offset+  ",utterance_end_offset: " + utterance_end_offset,e);
        }


        return nlpSentimentAndEntityAnalysisTranscriptionOutput.build();
    }

    private static NLPconversation buildNLPconversation(TranscriptionMessage.ConversationEvent payload) {
        NLPconversation nlPconversation = new NLPconversation();
        nlPconversation.setConversationID(payload.getConversation());
        nlPconversation.setNoOfUtterances(1);
        nlPconversation.setParticipant(payload.getNewMessagePayload().getParticipant());
        nlPconversation.setStreamStartTime(Long.valueOf(payload.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime().getSeconds()));
        nlPconversation.setUtteranceStartOffset(Long.valueOf(payload.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset().getSeconds()));
        return nlPconversation;
    }

    private static S2TNLPAPIAnalysisResponse buildS2TNLPAPIAnalysisResponse(TranscriptionMessage.ConversationEvent payload) {
        S2TNLPAPIAnalysisResponse s2TNLPAPIAnalysisResponse = new S2TNLPAPIAnalysisResponse();
        s2TNLPAPIAnalysisResponse = buildNLPSentimentAnalysisResponse(payload, s2TNLPAPIAnalysisResponse);
        s2TNLPAPIAnalysisResponse = buildNLPEntityAnalysisResponse(payload, s2TNLPAPIAnalysisResponse);
        return s2TNLPAPIAnalysisResponse;
    }


    private static S2TNLPAPIAnalysisResponse buildNLPSentimentAnalysisResponse(TranscriptionMessage.ConversationEvent payload,
                                                                               S2TNLPAPIAnalysisResponse s2TNLPAPIAnalysisResponse) {
        NLPSentimentAnalysis.Builder nlpSentimentAnalysis = NLPSentimentAnalysis.newBuilder();
        TranscriptionMessage.NLPSentimentAnalysisResponse sentimentAnalysisResultProto = payload.getNewMessagePayload().getNLPSentimentAnalysisResponse();


        DocumentSentiment.Builder docSentiment = DocumentSentiment.newBuilder();
        docSentiment.setMagnitude(sentimentAnalysisResultProto.getDocument().getMagnitude());
        docSentiment.setScore(sentimentAnalysisResultProto.getDocument().getScore());
        nlpSentimentAnalysis.setDocumentSentiment(docSentiment.build());

        nlpSentimentAnalysis.setLanguage(sentimentAnalysisResultProto.getLanguage());

        List<Sentences> avroSentenceList = new ArrayList<>();
        List<TranscriptionMessage.Sentences> sentencesListProto = sentimentAnalysisResultProto.getSentencesList();
        for (TranscriptionMessage.Sentences sentenceProto : sentencesListProto) {
            Sentences avroSentence = new Sentences();


            Text avroText = new Text();
            TranscriptionMessage.Text textProto = sentenceProto.getText();
            avroText.setBeginOffset(Long.valueOf(textProto.getBeginoffset()));
            avroText.setContent(textProto.getContent());
            avroSentence.setText(avroText);

            TranscriptionMessage.Sentences_Sentiment sentencesSentimentProto =
                    sentenceProto.getSentencesSentiment();
            Sentiment avroSentiment = new Sentiment();
            avroSentiment.setMagnitude(sentencesSentimentProto.getMagnitude());
            avroSentiment.setScore(sentencesSentimentProto.getScore());
            avroSentence.setSentiment(avroSentiment);

            avroSentenceList.add(avroSentence);
        }

        nlpSentimentAnalysis.setSentences(avroSentenceList);
        s2TNLPAPIAnalysisResponse.setNLPSentimentAnalysis(nlpSentimentAnalysis.build());

        return s2TNLPAPIAnalysisResponse;


    }


    private static S2TNLPAPIAnalysisResponse buildNLPEntityAnalysisResponse(TranscriptionMessage.ConversationEvent payload,
                                                                            S2TNLPAPIAnalysisResponse s2TNLPAPIAnalysisResponse) {

        NLPEntityAnalysis nlpEntityAnalyisAvro = new NLPEntityAnalysis();
        TranscriptionMessage.NLPEntityAnalysisResponse nlpEntityAnalysisResponseProto =
                payload.getNewMessagePayload().getNLPEntityAnalysisResponse();

        nlpEntityAnalyisAvro.setLanguage(nlpEntityAnalysisResponseProto.getLanguage());

        List<Entities> entitiesListAvro = new ArrayList<>();
        List<TranscriptionMessage.Entities> entitiesListProto =
                nlpEntityAnalysisResponseProto.getEntitiesList();
        for (TranscriptionMessage.Entities entity : entitiesListProto) {
            Entities avroEntity = new Entities();

            avroEntity.setName(entity.getName());
            avroEntity.setSalience(entity.getSalience());
            avroEntity.setType(entity.getTypeNlp());

            Mentions mentionsAvro = new Mentions();
            MentionsText mentionTextAvro = new MentionsText();

            TranscriptionMessage.Mentiontext mentionsTextProto = entity.getMentions().getText();
            mentionTextAvro.setBeginOffset(Long.valueOf(mentionsTextProto.getBeginoffset()));
            mentionTextAvro.setContent(mentionsTextProto.getContent());
            mentionsAvro.setMentionsText(mentionTextAvro);

            TranscriptionMessage.Mentions mentionsProto = entity.getMentions();
            mentionsAvro.setType(mentionsProto.getType());
            avroEntity.setMentions(mentionsAvro);

            TranscriptionMessage.Metadata metadataProto = entity.getMetadata();
            Metadata metadataAvro = new Metadata();
            metadataAvro.setAreaCode(metadataProto.getAreaCode());
            metadataAvro.setBroadRegion(metadataProto.getBroadRegion());
            metadataAvro.setCountry(metadataProto.getCountry());
            metadataAvro.setCurrency(metadataProto.getCurrency());
            metadataAvro.setDay(metadataProto.getDay());
            metadataAvro.setExtension(metadataProto.getExtension());
            metadataAvro.setLocality(metadataProto.getLocality());
            metadataAvro.setMid(metadataProto.getMid());
            metadataAvro.setMonth(metadataProto.getMonth());
            metadataAvro.setNarrowRegion(metadataProto.getNarrowRegion());
            metadataAvro.setNationalPrefix(metadataProto.getNationalPrefix());
            metadataAvro.setNumber(metadataProto.getNumber());
            metadataAvro.setPhoneNumber(metadataProto.getPhoneNumber());
            metadataAvro.setPostalCode(metadataProto.getPostalCode());
            metadataAvro.setStreetName(metadataProto.getStreetName());
            metadataAvro.setStreetNumber(metadataProto.getStreetNumber());
            metadataAvro.setSublocality(metadataProto.getSublocality());
            metadataAvro.setValue(metadataProto.getValue());
            metadataAvro.setWikipediaUrl(metadataProto.getWikipediaUrl());
            metadataAvro.setYear(metadataProto.getYear());
            avroEntity.setMetadata(metadataAvro);
            entitiesListAvro.add(avroEntity);
        }
        nlpEntityAnalyisAvro.setEntities(entitiesListAvro);

        s2TNLPAPIAnalysisResponse.setNLPEntityAnalysis(nlpEntityAnalyisAvro);


        return s2TNLPAPIAnalysisResponse;
    }

    public static void log(String prefix,
                     String conversationId, String participantId,
                     String utteranceWordCount, com.google.protobuf.Timestamp stream_start_time,
                     Duration utterance_start_offset, Duration utterance_end_offset, String time , long timeTakenMs) {

        String logMessage=prefix + " ConversationId: " + conversationId + ", ParticipantId: " + participantId +
                ", word_count: " + utteranceWordCount + ", Stream_Start_Time: " + stream_start_time +
                ", Utterance_start_offset: " + utterance_start_offset + ", utterance_end_offset: "
                + utterance_end_offset + ", "+time + timeTakenMs+"ms";

        LOG.debug(logMessage.replace("\r","").replace("\n",""));
    }
}
