/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.stt.transformers;

import com.bell.stt.avro.NLPSentimentAndEntityAnalysisTranscriptionOutput;
import com.bell.stt.converters.ProtoToAvro;
import com.bell.stt.proto.TranscriptionMessage;
import com.google.protobuf.Duration;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The class is responsible for converting the transcription in proto format to
 * Key value pair of conversation Id , Avro format of transcription.
 */
public class KafkaToAvroParDo extends DoFn<TranscriptionMessage.ConversationEvent, KV<String,
        NLPSentimentAndEntityAnalysisTranscriptionOutput>> {
    private static final Logger LOG = LoggerFactory.getLogger(KafkaToAvroParDo.class);
    private final Counter Success_counter = Metrics.counter("NLP-PubsubToKafka", "PUBSUBTOKAFKA_NLP_SUCCESS");
    private final Counter failure_counter = Metrics.counter("NLP-PubsubToKafka", "PUBSUBTOKAFKA_NLP_FAILURE");

    final TupleTag<TranscriptionMessage.ConversationEvent> DLQ;
    final TupleTag<KV<String, NLPSentimentAndEntityAnalysisTranscriptionOutput>> SUCCESS;

    public KafkaToAvroParDo(TupleTag<TranscriptionMessage.ConversationEvent> DLQ, TupleTag<KV<String,
            NLPSentimentAndEntityAnalysisTranscriptionOutput>> SUCCESS) {
        this.DLQ = DLQ;
        this.SUCCESS = SUCCESS;
    }

    /**
     * The method converts each proto to avro and writes to output
     * in the key value format.
     * key - conversation id
     * value - Transcription in Avro format
     * @param c - Incoming data
     */
    @ProcessElement
    public void processElement(ProcessContext c,MultiOutputReceiver out) {
            TranscriptionMessage.ConversationEvent event = c.element();
            String conversationId =event.getConversation();
            String ParticipantId =event.getNewMessagePayload().getParticipant();
            String utteranceWordCount=event.getNewMessagePayload().getWordCount();
        com.google.protobuf.Timestamp stream_start_time =event.getNewMessagePayload().getSpeechToTextInfo().getStreamStartTime();
        com.google.protobuf.Duration utterance_start_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceStartOffset();
        com.google.protobuf.Duration utterance_end_offset=event.getNewMessagePayload().getSpeechToTextInfo().getUtteranceEndOffset();
			try {
            long NLPAPIStartTime=Long.valueOf(event.getNewMessagePayload().getNLPAPIStartTime());
            long KafkastartTime= System.currentTimeMillis();

                log("Entering KafkaParDo for processing and publish message into Kafka", conversationId,
                        ParticipantId, utteranceWordCount, stream_start_time, utterance_start_offset,
                        utterance_end_offset,"Start Time ", KafkastartTime);
            c.output(SUCCESS,KV.of(c.element().getConversation(), ProtoToAvro.convertToAvroManually(c.element())));

            long endTime= System.currentTimeMillis();
                log("Exiting KafkaPardo for processing and publish message into Kafka", conversationId,
                        ParticipantId, utteranceWordCount, stream_start_time, utterance_start_offset,
                        utterance_end_offset,"Start Time ", KafkastartTime);

            Success_counter.inc();

        } catch (Exception e) {
            LOG.error("ERRNLP203 - Unable to publish to Kafka and Publish in the DLQ topic for "+" Conversation Id: " + conversationId
                    +", Participant: " + ParticipantId +" word_count: " + utteranceWordCount + ", Stream_Start_Time: "
                    + stream_start_time + ", Utterance_start_offset: " +utterance_start_offset
                    +  ", Utterance_end_offset: " + utterance_end_offset,e);
            c.output(DLQ,c.element());
            failure_counter.inc();
        }
    }
    private void log(String prefix,
                     String conversationId, String participantId,
                     String utteranceWordCount, com.google.protobuf.Timestamp stream_start_time,
                     Duration utterance_start_offset, Duration utterance_end_offset, String time , long timeTakenMs) {

        String logMessage=prefix + " ConversationId: " + conversationId + ", ParticipantId: " + participantId +
                ", word_count: " + utteranceWordCount + ", Stream_Start_Time: " + stream_start_time +
                ", Utterance_start_offset: " + utterance_start_offset + ", utterance_end_offset: "
                + utterance_end_offset + ", "+time + timeTakenMs+"ms";

        LOG.debug(logMessage.replace("\r","").replace("\n",""));
    }
}
