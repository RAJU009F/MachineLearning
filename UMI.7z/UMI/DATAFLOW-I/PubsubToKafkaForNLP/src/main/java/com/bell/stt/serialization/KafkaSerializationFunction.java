/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.stt.serialization;

import com.bell.stt.avro.NLPSentimentAndEntityAnalysisTranscriptionOutput;
import com.bell.stt.avro.Transcription;
import com.google.api.client.util.Preconditions;
import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.cloud.secretmanager.v1.SecretVersionName;


import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

/**
 * The class implements a serializable function for the Kafka producer config.
 */
public class KafkaSerializationFunction implements SerializableFunction<Map<String, Object>, Producer<String, NLPSentimentAndEntityAnalysisTranscriptionOutput>> {

    private static final Logger LOG = LoggerFactory.getLogger(KafkaSerializationFunction.class);
    private String keytabSecretId;
    private String trustStoreSecretId;
    private String trustStorePassword;
    private String kerbPrincipal;
    private String secretProjectId;
    private String kerberosServiceNameForKafka;
    private String schemaRegistryUrl;
    private String securityProtocol;

    private static final String SECRETVERSION = "latest";

    /**
     * Constructor
     * @param keytabSecretId secret Id for the keytab
     * @param trustStoreSecretId secret Id for the trust store
     * @param trustStorePassword trust store password
     * @param kerbPrincipal kerberos prinicipal
     * @param secretProjectId project Id of the secret manager
     * @param kerberosServiceNameForKafka Kafka service name
     * @param schemaRegistryUrl confluent schema registry URL
     */
    public KafkaSerializationFunction(String keytabSecretId, String trustStoreSecretId,
                                      String trustStorePassword, String kerbPrincipal,
                                      String secretProjectId, String kerberosServiceNameForKafka, String schemaRegistryUrl,
                                      String securityProtocol) {
        this.keytabSecretId = keytabSecretId;
        this.trustStoreSecretId = trustStoreSecretId;
        this.trustStorePassword = trustStorePassword;
        this.kerbPrincipal = kerbPrincipal;
        this.secretProjectId = secretProjectId;
        this.kerberosServiceNameForKafka = kerberosServiceNameForKafka;
        this.schemaRegistryUrl = schemaRegistryUrl;
        this.securityProtocol = securityProtocol;

    }

    /**
     * Method to build the configuration parameter for Kafka producer
     * @param inputParams params for initializing the kafka producer
     * @return Kafka producer built with the configuration parameters
     */
    public Producer<String, NLPSentimentAndEntityAnalysisTranscriptionOutput> apply(Map<String, Object> inputParams) {

        inputParams.put(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl);
        inputParams.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, securityProtocol);
        inputParams.put(ProducerConfig.CLIENT_ID_CONFIG, SerializationConstant.CLIENT_ID);
        inputParams.put(ProducerConfig.RETRIES_CONFIG, SerializationConstant.RETRY_VALUE);
        inputParams.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG, SerializationConstant.RETRY_BACKOFF_VALUE);
        inputParams.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION,
                SerializationConstant.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION_VALUE);
        inputParams.put(ProducerConfig.LINGER_MS_CONFIG, SerializationConstant.LINGER_VALUE);
        inputParams.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, SerializationConstant.COMPRESSION_TYPE_VALUE);

        if (keytabSecretId != null) {
            try {
                Path temp = downloadSecretToLocalFile(secretProjectId, keytabSecretId, "kafka", ".keytab");
                Preconditions.checkNotNull(temp);
                Preconditions.checkNotNull(kerbPrincipal);
                Preconditions.checkNotNull(kerberosServiceNameForKafka);
                String jaasConfig = String
                        .format(SerializationConstant.JASSCONFIG,SerializationConstant.KAFKA_KEYTAB, kerbPrincipal);
                inputParams.put(SaslConfigs.SASL_JAAS_CONFIG, jaasConfig);
                inputParams.put(SaslConfigs.SASL_MECHANISM, SaslConfigs.GSSAPI_MECHANISM);
                inputParams.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, kerberosServiceNameForKafka);
                inputParams.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, kerberosServiceNameForKafka);
                inputParams.put("ssl.endpoint.identification.algorithm", "");

            } catch (Exception e) {
                LOG.error("ERRNLP204 - Error in retrieving keytab from secrets ",e);
            }
        }

        if (trustStoreSecretId != null) {
            try {
                Path temp = downloadSecretToLocalFile(secretProjectId, trustStoreSecretId, "truststore", ".jks");
                String trustPassword = fetchValueFromSecretManager(secretProjectId, trustStorePassword);
                inputParams.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, temp.toString());
                inputParams.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, trustPassword);
            } catch (Exception e) {
                LOG.error("ERRNLP205 - Error in retrieving trust store details from secrets ", e);
            }
        }
        return new KafkaProducer<String, NLPSentimentAndEntityAnalysisTranscriptionOutput>(inputParams);
    }

    /**
     * Fetches the value corresponding to the secret id and writes it into a file.
     * Prefix - file name
     * Suffix - file extension
     * @param projectId
     * @param secretId
     * @param prefix
     * @param suffix
     * @return File name with the complete path
     * @throws IOException
     */
    private Path downloadSecretToLocalFile(String projectId, String secretId, String prefix, String suffix) throws IOException {
        Path tmpFile = Paths.get(prefix + suffix);
        if (Files.exists(tmpFile)) {
            try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
                SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, SECRETVERSION);
                AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);
                FileOutputStream outputStream = new FileOutputStream(tmpFile.getFileName().toFile());
                outputStream.write(response.getPayload().getData().toByteArray());
                outputStream.close();
            }
        }
        return tmpFile;
    }

    /**
     * Fetches the value from the secret manager for the corresponding secret Id.
     * @param projectId
     * @param secretId
     * @return Secret value
     * @throws IOException
     */
    private String fetchValueFromSecretManager(String projectId, String secretId) throws IOException {
        String tempValue = "";
        try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) {
            SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, SECRETVERSION);
            AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);
            tempValue = response.getPayload().getData().toStringUtf8();
        }
        return tempValue;
    }
}