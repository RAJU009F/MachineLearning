/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bell.stt.options;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.options.*;

public interface PubSubToKafkaOptions extends PipelineOptions, StreamingOptions , DataflowPipelineOptions {
    @Description(
            "The Cloud Pub/Sub subscription to consume from. "
                    + "The name should be in the format of "
                    + "projects/<project-id>/subscriptions/<subscription-name>.")
    //@Validation.Required
    ValueProvider<String> getInputSubscription();

    void setInputSubscription(ValueProvider<String> inputSubscription);

    @Description("Pub/Sub topic to read the input from")
    ValueProvider<String> getInputTopic();

    void setInputTopic(ValueProvider<String> value);

    @Description("Kafka Bootstrap Servers")
    ValueProvider<String> getBootstrapServers();

    void setBootstrapServers(ValueProvider<String> value);

    @Description("Kafka topic to write the output")
    ValueProvider<String> getOutputTopic();

    void setOutputTopic(ValueProvider<String> value);

    @Description(
            "The Cloud Pub/Sub subscription to consume from. "
                    + "The name should be in the format of "
                    + "projects/<project-id>/subscriptions/<subscription-name>.")
    //@Validation.Required
    ValueProvider<String> getDeadLetterTopic();

    void setDeadLetterTopic(ValueProvider<String> deadLetterTopic);

    @Description("secret id of the kerberos configuration from secret manager")
    ValueProvider<String> getKrb5ConfNameInSecretManager();

    void setKrb5ConfNameInSecretManager(ValueProvider<String> value);

    //getProjectIdForSecret

    @Description("secret manager project id")
    ValueProvider<String> getProjectIdForSecret();

    void setProjectIdForSecret(ValueProvider<String> value);

    @Description("secret id of the trust store name configuration from secret manager")
    ValueProvider<String> getTrustStoreNameInSecretManager();

    void setTrustStoreNameInSecretManager(ValueProvider<String> value);

    @Description("secret id of the keytab name configuration from secret manager")
    ValueProvider<String> getKeytabNameInSecretManager();

    void setKeytabNameInSecretManager(ValueProvider<String> value);

    @Description("secret id of the trust store password configuration from secret manager")
    ValueProvider<String> getTrustStorePasswordInSecretManager();

    void setTrustStorePasswordInSecretManager(ValueProvider<String> value);

    @Description("Kerberos principal")
    ValueProvider<String> getPrincipal();

    void setPrincipal(ValueProvider<String> value);

    @Description("Kafka service name")
    ValueProvider<String> getKafkaServiceName();

    void setKafkaServiceName(ValueProvider<String> value);

    @Description("MSK Schema Registry URL")
    ValueProvider<String> getschemaRegistryUrl();

    void setschemaRegistryUrl(ValueProvider<String> value);

    @Description("MSK Protocol")
    ValueProvider<String> getSecurityProtocol();

    void setSecurityProtocol(ValueProvider<String> value);

    @Validation.Required
    ValueProvider<String> getBucketName();
    void setBucketName(ValueProvider<String> bucketName);

    @Validation.Required
    ValueProvider<String> getConfigFileName();
    void setConfigFileName(ValueProvider<String> configFileName);

}